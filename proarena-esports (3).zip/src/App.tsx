import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import Wallet from './pages/Wallet';
import Profile from './pages/Profile';
import Auth from './pages/Auth';
import TournamentDetails from './pages/TournamentDetails';
import MyMatches from './pages/MyMatches';
import PaymentMethods from './pages/PaymentMethods';
import Tournaments from './pages/Tournaments';
import Deposit from './pages/Deposit';
import { Loader2, ShieldAlert } from 'lucide-react';
import AdminLayout from './admin/components/AdminLayout';
import AdminDashboard from './admin/pages/AdminDashboard';
import AdminUsers from './admin/pages/AdminUsers';
import AdminUserDetails from './admin/pages/AdminUserDetails';
import AdminTournaments from './admin/pages/AdminTournaments';
import AdminTransactions from './admin/pages/AdminTransactions';
import AdminWithdrawals from './admin/pages/AdminWithdrawals';
import AdminDeposits from './admin/pages/AdminDeposits';
import StaffManagement from './admin/pages/StaffManagement';
import AdminSettings from './admin/pages/AdminSettings';
import MaintenanceScreen from './components/MaintenanceScreen';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from './lib/firebase';
import { AppSettings } from './types';

function MaintenanceGuard({ children }: { children: React.ReactNode }) {
  const { profile } = useAuth();
  const [settings, setSettings] = React.useState<AppSettings | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'app'), (snap) => {
      if (snap.exists()) {
        setSettings(snap.data() as AppSettings);
      }
      setLoading(false);
    });
    return () => unsub();
  }, [profile]);

  if (loading) return null;

  const isAdmin = profile && ['moderator', 'support', 'admin', 'super_admin'].includes(profile.role);
  
  if (settings?.isMaintenance && !isAdmin) {
    return <MaintenanceScreen />;
  }

  return <>{children}</>;
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, profile, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-950">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }
  
  if (!user) {
    return <Navigate to="/auth" />;
  }

  if (profile?.isBlocked) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-950 p-6 text-center">
        <ShieldAlert className="w-16 h-16 text-red-500 mb-4" />
        <h1 className="text-3xl font-black text-white italic tracking-tighter uppercase mb-2">Account Blocked</h1>
        <p className="text-gray-400 font-bold uppercase tracking-widest text-xs mb-8">Access to your account has been restricted by management</p>
        <button 
          onClick={() => window.location.href = 'mailto:support@proarena.com'}
          className="px-8 py-4 bg-gray-900 border border-gray-800 text-white font-black text-xs uppercase tracking-widest rounded-2xl"
        >
          Contact Support
        </button>
      </div>
    );
  }
  
  return <>{children}</>;
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { user, profile, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-950">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }
  
  const isSystemAdmin = user?.email === 'sumitdhakad4424@gmail.com';
  const hasAccess = isSystemAdmin || (profile && ['moderator', 'support', 'admin', 'super_admin'].includes(profile.role));
  
  if (!user || !hasAccess) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-950 p-6 text-center">
        <ShieldAlert className="w-16 h-16 text-red-500 mb-4" />
        <h1 className="text-3xl font-black text-white italic tracking-tighter uppercase mb-2">Access Denied</h1>
        <p className="text-gray-400 font-bold uppercase tracking-widest text-xs mb-8 max-w-xs">You do not have administrative privileges to access this area.</p>
        <div className="flex flex-col gap-4 w-full max-w-xs">
          <button 
            onClick={() => window.location.href = '/'}
            className="w-full py-4 bg-gray-900 border border-gray-800 text-white font-black text-xs uppercase tracking-widest rounded-2xl"
          >
            Return Home
          </button>
          <div className="p-4 bg-gray-900/50 rounded-2xl border border-gray-800">
            <p className="text-[10px] text-gray-500 font-bold uppercase">Current Status</p>
            <p className="text-xs font-black text-red-400 uppercase italic mt-1">Role: {profile?.role || 'user'}</p>
          </div>
        </div>
      </div>
    );
  }
  
  return <>{children}</>;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/auth" element={<Auth />} />
          
          <Route path="/" element={
            <ProtectedRoute>
              <MaintenanceGuard>
                <Layout />
              </MaintenanceGuard>
            </ProtectedRoute>
          }>
            <Route index element={<Home />} />
            <Route path="tournaments" element={<Tournaments />} />
            <Route path="tournaments/:id" element={<TournamentDetails />} />
            <Route path="wallet" element={<Wallet />} />
            <Route path="matches" element={<MyMatches />} />
            <Route path="profile" element={<Profile />} />
            <Route path="deposit" element={<Deposit />} />
            <Route path="payment-methods" element={<PaymentMethods />} />
          </Route>

          {/* Admin Panel Routes */}
          <Route path="/admin" element={
            <AdminRoute>
              <AdminLayout />
            </AdminRoute>
          }>
            <Route index element={<AdminDashboard />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="users/:uid" element={<AdminUserDetails />} />
            <Route path="tournaments" element={<AdminTournaments />} />
            <Route path="transactions" element={<AdminTransactions />} />
            <Route path="withdrawals" element={<AdminWithdrawals />} />
            <Route path="deposits" element={<AdminDeposits />} />
            <Route path="staff" element={<StaffManagement />} />
            <Route path="settings" element={<AdminSettings />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
