import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, doc, updateDoc, deleteDoc, query, orderBy, getDocs, where, addDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { UserProfile, Transaction, Registration, UserRole } from '../../types';
import { 
  Search, 
  MoreVertical, 
  ShieldCheck, 
  ShieldAlert, 
  Edit2, 
  Trash2, 
  CreditCard,
  Mail,
  Gamepad2,
  Filter,
  Download,
  Eye,
  UserX,
  UserCheck,
  CheckCircle2,
  X,
  Loader2
} from 'lucide-react';
import { formatCurrency, cn } from '../../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';

export default function AdminUsers() {
  const navigate = useNavigate();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [editingBalance, setEditingBalance] = useState<{ uid: string, displayName: string, type: 'deposit' | 'winning', current: number } | null>(null);
  const [newBalance, setNewBalance] = useState('');
  const [editingRole, setEditingRole] = useState<UserProfile | null>(null);
  const [updating, setUpdating] = useState(false);
  const [toast, setToast] = useState<{ message: string, type: 'success' | 'error' } | null>(null);
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snap) => {
      setUsers(snap.docs.map(d => ({ ...d.data() } as UserProfile)));
      setLoading(false);
    }, (error) => {
      console.error("Users list error:", error);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleUpdateRole = async (newRole: UserRole) => {
    if (!editingRole) return;
    setUpdating(true);
    try {
      await updateDoc(doc(db, 'users', editingRole.uid), { role: newRole });
      showToast(`${editingRole.displayName} is now ${newRole}`);
      setEditingRole(null);
    } catch (err) {
      console.error(err);
      showToast("Promotion failed", 'error');
    } finally {
      setUpdating(false);
    }
  };

  const handleUpdateBalance = async () => {
    if (!editingBalance || !newBalance) return;
    setUpdating(true);
    const userRef = doc(db, 'users', editingBalance.uid);
    const balanceKey = `balance.${editingBalance.type}`;
    
    try {
      await updateDoc(userRef, {
        [balanceKey]: Number(newBalance)
      });
      
      // Also log a system transaction
      await addDoc(collection(db, 'transactions'), {
        userId: editingBalance.uid,
        amount: Math.abs(Number(newBalance) - editingBalance.current),
        type: Number(newBalance) > editingBalance.current ? 'deposit' : 'withdrawal',
        balanceType: editingBalance.type,
        status: 'success',
        description: `Admin Adjusted: ${editingBalance.type}`,
        createdAt: new Date().toISOString()
      });

      showToast(`Balance updated for ${editingBalance.displayName}`, 'success');
      setEditingBalance(null);
      setNewBalance('');
    } catch (err) {
      console.error("Balance Update Error:", err);
      showToast("Critical: Failed to update database", 'error');
    } finally {
      setUpdating(false);
    }
  };

  const handleToggleBlock = async (user: UserProfile) => {
    const userRef = doc(db, 'users', user.uid);
    try {
      await updateDoc(userRef, {
        isBlocked: !user.isBlocked
      });
      showToast(`User ${user.isBlocked ? 'unblocked' : 'blocked'} successfully`);
      setActiveMenu(null);
    } catch (err) {
      console.error(err);
      showToast("Action failed", 'error');
    }
  };

  const handleDeleteUser = async (user: UserProfile) => {
    if (!confirm(`Are you sure you want to delete ${user.displayName}? \n\nIMPORTANT: This will only remove their data from Firestore. To completely block access, you must also delete their account from the Firebase Authentication console.`)) return;
    
    try {
      await deleteDoc(doc(db, 'users', user.uid));
      alert("Firestore data deleted. Remember to also remove this user from Firebase Auth console: " + user.email);
      showToast("User record removed", 'success');
      setActiveMenu(null);
    } catch (err) {
      console.error(err);
      showToast("Failed to delete user record", 'error');
    }
  };

  const filteredUsers = users.filter(u => 
    u.displayName.toLowerCase().includes(search.toLowerCase()) || 
    u.email.toLowerCase().includes(search.toLowerCase()) ||
    (u.proId && u.proId.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-8 pb-20 relative">
      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: -50, x: '-50%' }}
            animate={{ opacity: 1, y: 20, x: '-50%' }}
            exit={{ opacity: 0, y: -50, x: '-50%' }}
            className={cn(
              "fixed top-4 left-1/2 z-[1000] px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border",
              toast.type === 'success' ? "bg-green-600 border-green-500 text-white" : "bg-red-600 border-red-500 text-white"
            )}
          >
            {toast.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <ShieldAlert className="w-5 h-5" />}
            <span className="text-xs font-bold uppercase tracking-widest">{toast.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-black text-white italic tracking-tighter">USERS</h1>
          <p className="text-gray-500 font-medium">Manage player profiles and rewards</p>
        </div>
        <div className="flex gap-3 w-full md:w-auto">
           <button className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-3 bg-gray-900 border border-gray-800 rounded-xl hover:bg-gray-800 transition-colors">
            <Download className="w-5 h-5" />
            <span className="text-sm font-bold uppercase tracking-widest">Export</span>
          </button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 bg-gray-900 p-4 rounded-3xl border border-gray-800">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
          <input
            type="text"
            placeholder="Search by name, email or Pro ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-3 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all"
          />
        </div>
        <button className="px-6 py-3 bg-gray-950 border border-gray-800 rounded-2xl text-gray-400 hover:text-white flex items-center justify-center gap-2 transition-all">
          <Filter className="w-5 h-5" />
          <span className="text-sm font-bold uppercase tracking-widest">Filters</span>
        </button>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">User</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Pro ID</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Status</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Balance</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Joined</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {loading ? (
                <tr>
                  <td colSpan={5} className="py-20 text-center">
                    <Loader2 className="w-10 h-10 animate-spin text-blue-500 mx-auto mb-4" />
                    <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Loading Users Database...</p>
                  </td>
                </tr>
              ) : filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-20 text-center">
                    <p className="text-gray-500 font-bold uppercase tracking-widest">No users found</p>
                  </td>
                </tr>
              ) : (
                filteredUsers.map((u) => (
                  <tr key={u.uid} className="group hover:bg-gray-950/50 transition-colors">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <div className={cn(
                          "w-12 h-12 rounded-2xl flex items-center justify-center text-lg font-black italic border",
                          u.isBlocked ? "bg-red-600/10 border-red-500/20 text-red-500" : "bg-blue-600/20 border-blue-500/20 text-blue-500"
                        )}>
                          {u.displayName[0].toUpperCase()}
                        </div>
                        <div>
                          <p className="font-bold text-white group-hover:text-blue-400 transition-colors uppercase tracking-tight">{u.displayName}</p>
                          <p className="text-[10px] text-gray-500 lowercase font-medium">{u.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="bg-gray-800/50 border border-gray-700/50 px-3 py-1.5 rounded-xl w-fit">
                        <span className="text-xs font-black text-blue-400 italic tracking-widest">{u.proId || '000000'}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      {u.isBlocked ? (
                        <div className="flex items-center gap-2 text-red-500 bg-red-500/10 px-3 py-1 rounded-full w-fit">
                          <ShieldAlert className="w-3 h-3" />
                          <span className="text-[10px] font-bold uppercase tracking-widest">Blocked</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 text-green-500 bg-green-500/10 px-3 py-1 rounded-full w-fit">
                          <ShieldCheck className="w-3 h-3" />
                          <span className="text-[10px] font-bold uppercase tracking-widest">Active</span>
                        </div>
                      )}
                    </td>
                    <td className="px-8 py-6">
                      <div className="space-y-1">
                        <div 
                          onClick={() => {
                            setEditingBalance({ uid: u.uid, displayName: u.displayName, type: 'deposit', current: u.balance.deposit });
                            setNewBalance(u.balance.deposit.toString());
                          }}
                          className="flex items-center justify-between text-xs font-bold text-blue-500 cursor-pointer hover:bg-blue-500/10 rounded-lg px-3 py-1 transition-all border border-transparent hover:border-blue-500/20"
                        >
                          <span className="opacity-50 text-[10px] uppercase tracking-widest">Dep:</span>
                          <span>{formatCurrency(u.balance.deposit)}</span>
                        </div>
                        <div 
                          onClick={() => {
                            setEditingBalance({ uid: u.uid, displayName: u.displayName, type: 'winning', current: u.balance.winning });
                            setNewBalance(u.balance.winning.toString());
                          }}
                          className="flex items-center justify-between text-xs font-bold text-green-500 cursor-pointer hover:bg-green-500/10 rounded-lg px-3 py-1 transition-all border border-transparent hover:border-green-500/20"
                        >
                          <span className="opacity-50 text-[10px] uppercase tracking-widest">Win:</span>
                          <span>{formatCurrency(u.balance.winning)}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                        {format(new Date(u.createdAt), 'MMM dd, yyyy')}
                      </p>
                    </td>
                    <td className="px-8 py-6 text-right relative">
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={() => setActiveMenu(activeMenu === u.uid ? null : u.uid)}
                          className={cn(
                            "p-3 rounded-xl transition-all border",
                            activeMenu === u.uid ? "bg-blue-600 border-blue-500 text-white" : "bg-gray-950 border-gray-800 text-gray-500 hover:text-white"
                          )}
                        >
                          <MoreVertical className="w-5 h-5" />
                        </button>

                        <AnimatePresence>
                          {activeMenu === u.uid && (
                            <>
                              <div 
                                className="fixed inset-0 z-40" 
                                onClick={() => setActiveMenu(null)} 
                              />
                              <motion.div
                                initial={{ opacity: 0, scale: 0.95, x: 20 }}
                                animate={{ opacity: 1, scale: 1, x: 0 }}
                                exit={{ opacity: 0, scale: 0.95, x: 20 }}
                                className="absolute right-20 top-6 z-50 bg-gray-900 border border-gray-800 rounded-2xl p-2 w-48 shadow-2xl"
                              >
                                <button 
                                  onClick={() => setEditingRole(u)}
                                  className="w-full flex items-center gap-3 px-4 py-3 text-blue-400 hover:text-white hover:bg-gray-800 rounded-xl transition-all text-xs font-bold uppercase tracking-widest"
                                >
                                  <ShieldCheck className="w-4 h-4" />
                                  Manage Role
                                </button>
                                <button 
                                  onClick={() => navigate(`/admin/users/${u.uid}`)}
                                  className="w-full flex items-center gap-3 px-4 py-3 text-gray-400 hover:text-white hover:bg-gray-800 rounded-xl transition-all text-xs font-bold uppercase tracking-widest"
                                >
                                  <Eye className="w-4 h-4" />
                                  View Details
                                </button>
                                <button 
                                  onClick={() => handleToggleBlock(u)}
                                  className={cn(
                                    "w-full flex items-center gap-3 px-4 py-3 transition-all text-xs font-bold uppercase tracking-widest rounded-xl",
                                    u.isBlocked ? "text-green-500 hover:bg-green-500/10" : "text-yellow-500 hover:bg-yellow-500/10"
                                  )}
                                >
                                  {u.isBlocked ? <UserCheck className="w-4 h-4" /> : <UserX className="w-4 h-4" />}
                                  {u.isBlocked ? 'Unblock' : 'Block User'}
                                </button>
                                <div className="h-px bg-gray-800 my-1" />
                                <button 
                                  onClick={async () => {
                                    if (updating) return;
                                    setUpdating(true);
                                    await handleDeleteUser(u);
                                    setUpdating(false);
                                  }}
                                  className="w-full flex items-center gap-3 px-4 py-3 text-red-500 hover:bg-red-500/10 rounded-xl transition-all text-xs font-bold uppercase tracking-widest disabled:opacity-50"
                                >
                                  {updating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                                  Delete
                                </button>
                              </motion.div>
                            </>
                          )}
                        </AnimatePresence>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Balance Edit Modal */}
      <AnimatePresence>
        {editingBalance && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setEditingBalance(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 w-full max-w-sm relative z-10 shadow-2xl"
            >
              <div className="flex items-center gap-4 mb-8">
                <div className={cn(
                  "w-14 h-14 rounded-2xl flex items-center justify-center border",
                  editingBalance.type === 'deposit' ? "bg-blue-600/20 border-blue-500/20 text-blue-500" : "bg-green-600/20 border-green-500/20 text-green-500"
                )}>
                  <CreditCard className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="font-black text-white italic text-xl uppercase tracking-tighter">Adjust {editingBalance.type}</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{editingBalance.displayName}</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">New Balance Amount ($)</label>
                  <input
                    type="number"
                    value={newBalance}
                    onChange={(e) => setNewBalance(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-3xl py-6 px-6 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50 text-4xl font-black italic"
                    autoFocus
                  />
                  <div className="flex justify-between px-1">
                    <p className="text-[9px] font-bold text-gray-600 uppercase tracking-widest">Current Balance</p>
                    <p className="text-[9px] font-bold text-white uppercase tracking-widest">{formatCurrency(editingBalance.current)}</p>
                  </div>
                </div>

                <div className="flex gap-4 pt-4">
                  <button
                    onClick={() => setEditingBalance(null)}
                    disabled={updating}
                    className="flex-1 bg-gray-950 border border-gray-800 text-gray-500 hover:text-white font-black py-5 rounded-2xl uppercase tracking-widest text-[10px] transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleUpdateBalance}
                    disabled={updating}
                    className={cn(
                      "flex-1 text-white font-black py-5 rounded-2xl shadow-xl uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-2",
                      editingBalance.type === 'deposit' ? "bg-blue-600 shadow-blue-600/20" : "bg-green-600 shadow-green-600/20"
                    )}
                  >
                    {updating ? <Loader2 className="w-5 h-5 animate-spin" /> : "Confirm Update"}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Role Edit Modal */}
      <AnimatePresence>
        {editingRole && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setEditingRole(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 w-full max-w-sm relative z-10 shadow-2xl"
            >
              <div className="flex items-center gap-4 mb-8">
                <div className="w-14 h-14 rounded-2xl bg-blue-600/20 flex items-center justify-center border border-blue-500/20 text-blue-500">
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="font-black text-white italic text-xl uppercase tracking-tighter">Manage Role</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{editingRole.displayName}</p>
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Select New Level</p>
                <div className="grid gap-2">
                  {[
                    { role: 'user', label: 'User', desc: 'Standard Access' },
                    { role: 'moderator', label: 'Moderator', desc: 'Manage Matches' },
                    { role: 'support', label: 'Support', desc: 'Manage Users' },
                    { role: 'admin', label: 'Admin', desc: 'Full Control' }
                  ].map((item) => (
                    <button
                      key={item.role}
                      onClick={() => handleUpdateRole(item.role as UserRole)}
                      disabled={updating}
                      className={cn(
                        "w-full flex items-center justify-between p-4 rounded-2xl border transition-all text-left",
                        editingRole.role === item.role 
                          ? "bg-blue-600/10 border-blue-600/50" 
                          : "bg-gray-950 border-gray-800 hover:border-gray-700"
                      )}
                    >
                      <div>
                        <p className={cn("text-xs font-black uppercase tracking-widest", editingRole.role === item.role ? "text-blue-500" : "text-white")}>
                          {item.label}
                        </p>
                        <p className="text-[9px] text-gray-500 font-bold uppercase">{item.desc}</p>
                      </div>
                      {editingRole.role === item.role && (
                         <CheckCircle2 className="w-4 h-4 text-blue-500" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => setEditingRole(null)}
                className="w-full mt-6 py-4 bg-gray-950 border border-gray-800 text-gray-500 hover:text-white font-black rounded-2xl uppercase tracking-widest text-[10px] transition-all"
              >
                Cancel
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

