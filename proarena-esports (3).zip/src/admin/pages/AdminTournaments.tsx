import React, { useEffect, useState } from 'react';
import { 
  collection, 
  onSnapshot, 
  query, 
  orderBy, 
  doc, 
  updateDoc, 
  addDoc, 
  deleteDoc,
  getDocs,
  where,
  writeBatch
} from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Tournament } from '../../types';
import { 
  Plus, 
  Edit3, 
  Trash2, 
  Gamepad2, 
  Users, 
  Trophy, 
  Clock, 
  Lock,
  ChevronRight,
  MoreHorizontal,
  X,
  CheckCircle2,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { formatCurrency, cn } from '../../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';

export default function AdminTournaments() {
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [creating, setCreating] = useState(false);
  
  const [showCredentials, setShowCredentials] = useState(false);
  const [showParticipants, setShowParticipants] = useState(false);
  const [participants, setParticipants] = useState<any[]>([]);
  const [loadingParticipants, setLoadingParticipants] = useState(false);
  const [editingTournament, setEditingTournament] = useState<Tournament | null>(null);
  const [credData, setCredData] = useState({ roomId: '', roomPassword: '', thumbnail: '' });
  const [updatingCreds, setUpdatingCreds] = useState(false);
  const [showResultModal, setShowResultModal] = useState(false);
  const [resultData, setResultData] = useState({ winnerName: '', winnerProId: '', winnerKills: 0, winnerPrize: 0 });
  const [publishingResult, setPublishingResult] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    game: 'Free Fire MAX',
    gameMode: 'Battle Royale',
    team1Name: '',
    team2Name: '',
    player1Name: '',
    player2Name: '',
    map: 'Bermuda',
    version: 'Mobile',
    entryFee: 0,
    prizePool: 0,
    adminProfit: 0,
    perKill: 0,
    maxPlayers: 48,
    matchTime: '',
    status: 'upcoming' as const,
    type: 'paid' as const,
    thumbnail: ''
  });

  const [isPrizeManual, setIsPrizeManual] = useState(false);

  useEffect(() => {
    if (isPrizeManual) return;

    let players = 48;
    if (formData.gameMode === 'Clash Squad') players = 8;
    else if (formData.gameMode === 'Lone Wolf') players = 2;
    else if (formData.gameMode === 'Battle Royale') players = 48;

    const total = formData.entryFee * players;
    const calculatedPrize = Math.max(0, total - (formData.adminProfit || 0));
    
    setFormData(prev => ({ 
      ...prev, 
      maxPlayers: players,
      prizePool: calculatedPrize
    }));
  }, [formData.gameMode, formData.entryFee, formData.adminProfit, isPrizeManual]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, thumbnail: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const [declaringResult, setDeclaringResult] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    const q = query(collection(db, 'tournaments'), orderBy('matchTime', 'desc'));
    const unsubscribe = onSnapshot(q, (snap) => {
      setTournaments(snap.docs.map(d => ({ id: d.id, ...d.data() } as Tournament)));
      setLoading(false);
    }, (error) => {
      console.error("Tournaments Fetch Error:", error);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (creating) return;
    
    setCreating(true);
    try {
      await addDoc(collection(db, 'tournaments'), {
        ...formData,
        playersCount: 0,
        createdAt: new Date().toISOString()
      });
      alert('Tournament published successfully!');
      setShowCreate(false);
      setFormData({
        title: '',
        game: 'Free Fire MAX',
        gameMode: 'Battle Royale',
        team1Name: '',
        team2Name: '',
        player1Name: '',
        player2Name: '',
        map: 'Bermuda',
        version: 'Mobile',
        entryFee: 0,
        prizePool: 0,
        adminProfit: 0,
        perKill: 0,
        maxPlayers: 48,
        matchTime: '',
        status: 'upcoming',
        type: 'paid',
        thumbnail: ''
      });
      setIsPrizeManual(false);
    } catch (err) {
      console.error(err);
      alert('Failed to publish tournament. Please try again.');
    } finally {
      setCreating(false);
    }
  };

  const viewParticipants = async (t: Tournament) => {
    setEditingTournament(t);
    setLoadingParticipants(true);
    setShowParticipants(true);
    try {
      const q = query(collection(db, 'tournaments', t.id, 'registrations'), orderBy('joinedAt', 'desc'));
      const snap = await getDocs(q);
      setParticipants(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingParticipants(false);
    }
  };

  const handleUpdateStatus = async (id: string, status: Tournament['status']) => {
    try {
      await updateDoc(doc(db, 'tournaments', id), { status });
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this match?')) return;
    
    setDeletingId(id);
    try {
      await deleteDoc(doc(db, 'tournaments', id));
      alert('Match deleted successfully');
    } catch (err) {
      console.error(err);
      alert('Failed to delete match');
    } finally {
      setDeletingId(null);
    }
  };

  const openCredentials = (t: Tournament) => {
    setEditingTournament(t);
    setCredData({ 
      roomId: t.roomId || '', 
      roomPassword: t.roomPassword || '',
      thumbnail: t.thumbnail || ''
    });
    setShowCredentials(true);
  };

  const handleUpdateCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTournament || updatingCreds) return;

    setUpdatingCreds(true);
    try {
      await updateDoc(doc(db, 'tournaments', editingTournament.id), {
        roomId: credData.roomId,
        roomPassword: credData.roomPassword,
        thumbnail: credData.thumbnail
      });
      alert('Tournament updated successfully!');
      setShowCredentials(false);
    } catch (err) {
      console.error(err);
      alert('Failed to update tournament.');
    } finally {
      setUpdatingCreds(false);
    }
  };

  const openResultModal = (t: Tournament) => {
    setEditingTournament(t);
    setResultData({ 
      winnerName: t.winnerName || (t.gameMode === 'Clash Squad' ? t.team1Name || 'Team 1' : t.gameMode === 'Lone Wolf' ? t.player1Name || 'Player 1' : ''), 
      winnerProId: t.winnerProId || '',
      winnerKills: t.winnerKills || 0,
      winnerPrize: t.winnerPrize || t.prizePool
    });
    setShowResultModal(true);
  };

  const handlePublishResult = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTournament || publishingResult) return;

    setPublishingResult(true);
    try {
      // 1. Update tournament status and results
      await updateDoc(doc(db, 'tournaments', editingTournament.id), {
        ...resultData,
        status: 'completed'
      });

      // 2. Automatically credit winner if Player ID is provided
      if (resultData.winnerProId && resultData.winnerPrize > 0) {
        const usersRef = collection(db, 'users');
        const q = query(usersRef, where('proId', '==', resultData.winnerProId.trim()));
        const snap = await getDocs(q);
        
        if (!snap.empty) {
          const userDoc = snap.docs[0];
          const userData = userDoc.data();
          const batch = writeBatch(db);

          // Update balance
          batch.update(userDoc.ref, {
            'balance.winning': (userData.balance?.winning || 0) + resultData.winnerPrize
          });

          // Log transaction
          const transRef = doc(collection(db, 'transactions'));
          batch.set(transRef, {
            userId: userDoc.id,
            amount: resultData.winnerPrize,
            type: 'winning',
            balanceType: 'winning',
            status: 'success',
            description: `Prize from ${editingTournament.title}`,
            createdAt: new Date().toISOString()
          });

          await batch.commit();
          alert(`Match result published and prize of $${resultData.winnerPrize} credited to Player ID ${resultData.winnerProId}`);
        } else {
          alert('Match result published, but Player ID was not found. Please credit the winner manually.');
        }
      } else {
        alert('Match result published successfully!');
      }

      setShowResultModal(false);
    } catch (err) {
      console.error(err);
      alert('Failed to publish result.');
    } finally {
      setPublishingResult(false);
    }
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-black text-white italic tracking-tighter">TOURNAMENTS</h1>
          <p className="text-gray-500 font-medium">Create and manage competitive events</p>
        </div>
        <button 
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl shadow-xl shadow-blue-600/20 transition-all active:scale-95"
        >
          <Plus className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-sm">Create New</span>
        </button>
      </div>

      {/* Stats Quickbar */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {[
          { label: 'Upcoming', count: tournaments.filter(t => t.status === 'upcoming').length, color: 'text-blue-500' },
          { label: 'Ongoing', count: tournaments.filter(t => t.status === 'ongoing').length, color: 'text-orange-500' },
          { label: 'Completed', count: tournaments.filter(t => t.status === 'completed').length, color: 'text-green-500' },
          { label: 'Cancelled', count: tournaments.filter(t => t.status === 'cancelled').length, color: 'text-red-500' },
          { label: 'Total Prize Pool', count: formatCurrency(tournaments.reduce((a, b) => a + b.prizePool, 0)), color: 'text-yellow-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-gray-900 border border-gray-800 p-4 rounded-2xl">
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">{stat.label}</p>
            <p className={cn("text-xl font-black italic", stat.color)}>{stat.count}</p>
          </div>
        ))}
      </div>

      {/* Tournament List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {tournaments.map((t) => (
          <motion.div 
            key={t.id}
            layout
            className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-6 hover:border-gray-700 transition-colors group"
          >
            <div className="flex justify-between items-start mb-6">
              <div className="flex gap-4">
                <div className="w-14 h-14 rounded-2xl bg-gray-800 flex items-center justify-center overflow-hidden">
                  {t.thumbnail ? (
                    <img src={t.thumbnail} alt={t.title} className="w-full h-full object-cover" />
                  ) : (
                    <Gamepad2 className="w-8 h-8 text-blue-500" />
                  )}
                </div>
                <div>
                  <h3 className="font-black text-white text-lg group-hover:text-blue-400 transition-colors uppercase tracking-tight italic">{t.title}</h3>
                  <p className="text-xs text-gray-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {format(new Date(t.matchTime), 'PPP p')}
                  </p>
                </div>
              </div>
              <div className={cn(
                "px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest",
                t.status === 'upcoming' ? "bg-blue-600/10 text-blue-500" :
                t.status === 'ongoing' ? "bg-orange-600/10 text-orange-500" :
                t.status === 'completed' ? "bg-green-600/10 text-green-500" :
                "bg-red-600/10 text-red-500"
              )}>
                {t.status}
              </div>
            </div>

            <div className="flex flex-wrap gap-2 mb-6">
              <div className="px-3 py-1 bg-blue-600/10 border border-blue-500/20 text-blue-500 rounded-lg text-[10px] font-black uppercase tracking-widest">
                {t.gameMode || 'Battle Royale'}
              </div>
              <div className="px-3 py-1 bg-purple-600/10 border border-purple-500/20 text-purple-500 rounded-lg text-[10px] font-black uppercase tracking-widest">
                {t.map || 'Bermuda'}
              </div>
              <div className="px-3 py-1 bg-yellow-600/10 border border-yellow-500/20 text-yellow-500 rounded-lg text-[10px] font-black uppercase tracking-widest">
                {t.version || 'Mobile'}
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-gray-950 p-3 rounded-2xl border border-gray-800 text-center">
                <p className="text-[8px] font-bold text-gray-500 uppercase mb-1">Entry</p>
                <p className="text-sm font-black text-white">{t.entryFee === 0 ? 'FREE' : formatCurrency(t.entryFee)}</p>
              </div>
              <div className="bg-gray-950 p-3 rounded-2xl border border-gray-800 text-center">
                <p className="text-[8px] font-bold text-gray-500 uppercase mb-1">Prize</p>
                <p className="text-sm font-black text-yellow-500">{formatCurrency(t.prizePool)}</p>
              </div>
              <div className="bg-gray-950 p-3 rounded-2xl border border-gray-800 text-center">
                <p className="text-[8px] font-bold text-gray-500 uppercase mb-1">Per Kill</p>
                <p className="text-sm font-black text-orange-500">{formatCurrency(t.perKill)}</p>
              </div>
              <div className="bg-gray-950 p-3 rounded-2xl border border-gray-800 text-center">
                <p className="text-[8px] font-bold text-gray-500 uppercase mb-1">Players</p>
                <p className="text-sm font-black text-white">{t.playersCount}/{t.maxPlayers}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between px-1">
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Update Match Status</p>
                <p className="text-[8px] font-bold text-gray-600 uppercase">Changes reflect instantly for users</p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {(['upcoming', 'ongoing', 'completed', 'cancelled'] as const).map((status) => (
                  <button
                    key={status}
                    onClick={() => handleUpdateStatus(t.id, status)}
                    className={cn(
                      "py-3 rounded-xl font-black text-[9px] uppercase tracking-tighter transition-all border",
                      t.status === status
                        ? status === 'upcoming' ? "bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-600/20" :
                          status === 'ongoing' ? "bg-orange-600 border-orange-500 text-white shadow-lg shadow-orange-600/20" :
                          status === 'completed' ? "bg-green-600 border-green-500 text-white shadow-lg shadow-green-600/20" :
                          "bg-red-600 border-red-500 text-white shadow-lg shadow-red-600/20"
                        : "bg-gray-950 border-gray-800 text-gray-500 hover:border-gray-700 hover:text-gray-300"
                    )}
                  >
                    {status}
                  </button>
                ))}
              </div>

              <div className="flex gap-2 pt-2">
                <button 
                  onClick={() => viewParticipants(t)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-blue-600/10 border border-blue-500/20 text-blue-500 rounded-xl hover:bg-blue-600/20 transition-all"
                >
                  <Users className="w-4 h-4" />
                  <span className="font-bold text-[10px] uppercase tracking-widest">Players ({t.playersCount})</span>
                </button>
                <button 
                  onClick={() => openResultModal(t)}
                  className={cn(
                    "flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl transition-all font-black text-[10px] uppercase tracking-widest",
                    t.status === 'completed'
                      ? "bg-yellow-600/10 border border-yellow-500/20 text-yellow-500 hover:bg-yellow-600/20"
                      : "bg-green-600/10 border border-green-500/20 text-green-500 hover:bg-green-600/20"
                  )}
                >
                  <Trophy className="w-4 h-4" />
                  Declare Result
                </button>
                <button 
                  onClick={() => openCredentials(t)}
                  className="flex items-center justify-center p-3 bg-gray-950 border border-gray-800 text-gray-400 rounded-xl hover:text-white hover:border-blue-500 transition-all"
                >
                  <Lock className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => handleDelete(t.id)}
                  disabled={deletingId === t.id}
                  className="p-3 bg-red-600/10 text-red-500 rounded-xl hover:bg-red-600/20 border border-transparent hover:border-red-600/30 transition-all flex items-center justify-center disabled:opacity-50"
                  title="Delete Tournament"
                >
                  {deletingId === t.id ? <Loader2 className="w-5 h-5 animate-spin" /> : <Trash2 className="w-5 h-5" />}
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Create Modal */}
      <AnimatePresence>
        {showCreate && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCreate(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 w-full max-w-lg relative z-10 shadow-2xl flex flex-col max-h-[90vh]"
            >
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-2xl font-black text-white italic tracking-tighter">NEW TOURNAMENT</h3>
                <button onClick={() => setShowCreate(false)} className="p-2 hover:bg-gray-800 rounded-full">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleCreate} className="space-y-6 overflow-y-auto pr-2 custom-scrollbar">
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Tournament Thumbnail</label>
                  <div className="flex items-center gap-4">
                    <div className="w-24 h-24 bg-gray-950 border border-gray-800 rounded-2xl overflow-hidden flex items-center justify-center group relative">
                      {formData.thumbnail ? (
                        <>
                          <img src={formData.thumbnail} alt="Preview" className="w-full h-full object-cover" />
                          <button 
                            type="button"
                            onClick={() => setFormData({ ...formData, thumbnail: '' })}
                            className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-5 h-5 text-white" />
                          </button>
                        </>
                      ) : (
                        <Gamepad2 className="w-8 h-8 text-gray-800" />
                      )}
                    </div>
                    <div className="flex-1">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="hidden"
                        id="thumbnail-upload"
                      />
                      <label 
                        htmlFor="thumbnail-upload"
                        className="inline-block bg-gray-800 hover:bg-gray-700 text-white text-[10px] font-black uppercase tracking-widest py-3 px-6 rounded-xl cursor-pointer transition-all border border-gray-700"
                      >
                        Choose Image
                      </label>
                      <p className="text-[7px] text-gray-500 mt-2 uppercase font-black tracking-widest leading-tight">Recommended: 16:9 aspect ratio<br />Max size: 500KB (Base64)</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Game</label>
                    <select
                      value={formData.game}
                      onChange={(e) => setFormData({ ...formData, game: e.target.value })}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    >
                      <option>Free Fire MAX</option>
                      <option>Battlegrounds Mobile India</option>
                      <option>COD Mobile</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Game Mode</label>
                    <select
                      value={formData.gameMode}
                      onChange={(e) => {
                        setFormData({ ...formData, gameMode: e.target.value });
                        setIsPrizeManual(false);
                      }}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    >
                      <option>Battle Royale</option>
                      <option>Clash Squad</option>
                      <option>Lone Wolf</option>
                    </select>
                  </div>
                </div>

                {formData.gameMode === 'Clash Squad' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Team 1 Name</label>
                      <input
                        type="text"
                        value={formData.team1Name}
                        onChange={(e) => setFormData({ ...formData, team1Name: e.target.value })}
                        className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                        placeholder="e.g. Team Alpha"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Team 2 Name</label>
                      <input
                        type="text"
                        value={formData.team2Name}
                        onChange={(e) => setFormData({ ...formData, team2Name: e.target.value })}
                        className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                        placeholder="e.g. Team Beta"
                      />
                    </div>
                  </div>
                )}

                {formData.gameMode === 'Lone Wolf' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Player 1 Name</label>
                      <input
                        type="text"
                        value={formData.player1Name}
                        onChange={(e) => setFormData({ ...formData, player1Name: e.target.value })}
                        className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                        placeholder="e.g. Sumit"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Player 2 Name</label>
                      <input
                        type="text"
                        value={formData.player2Name}
                        onChange={(e) => setFormData({ ...formData, player2Name: e.target.value })}
                        className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                        placeholder="e.g. Rahul"
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">
                    {formData.gameMode === 'Battle Royale' ? 'Match Title' : 'Special Note'}
                  </label>
                  <input
                    required
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    placeholder={formData.gameMode === 'Battle Royale' ? "e.g. Pro Battle Series 1" : "e.g. Championship Finals"}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Map Name</label>
                    <input
                      required
                      type="text"
                      value={formData.map}
                      onChange={(e) => setFormData({ ...formData, map: e.target.value })}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                      placeholder="e.g. Bermuda / Erangel"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Version</label>
                    <select
                      value={formData.version}
                      onChange={(e) => setFormData({ ...formData, version: e.target.value })}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    >
                      <option>Mobile</option>
                      <option>PC / Emulator</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Entry Fee ($)</label>
                    <input
                      required
                      type="number"
                      value={formData.entryFee}
                      onChange={(e) => setFormData({ ...formData, entryFee: Number(e.target.value) })}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Admin Profit ($)</label>
                    <input
                      required
                      type="number"
                      value={formData.adminProfit}
                      onChange={(e) => setFormData({ ...formData, adminProfit: Number(e.target.value) })}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Prize Pool ($)</label>
                    <input
                      required
                      type="number"
                      value={formData.prizePool}
                      onChange={(e) => {
                        setFormData({ ...formData, prizePool: Number(e.target.value) });
                        setIsPrizeManual(true);
                      }}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Per Kill ($)</label>
                    <input
                      required
                      type="number"
                      value={formData.perKill}
                      onChange={(e) => setFormData({ ...formData, perKill: Number(e.target.value) })}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Match Time</label>
                  <input
                    required
                    type="datetime-local"
                    value={formData.matchTime}
                    onChange={(e) => setFormData({ ...formData, matchTime: e.target.value })}
                    className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                  />
                </div>

                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Max Players (Auto-set by Mode)</label>
                    <input
                      required
                      readOnly
                      type="number"
                      value={formData.maxPlayers}
                      className="w-full bg-gray-900 border border-gray-800 rounded-2xl py-4 px-5 text-gray-500 cursor-not-allowed"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={creating}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-600/20 transition-all uppercase tracking-[0.2em] disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {creating ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Publishing...
                    </>
                  ) : (
                    'Publish Tournament'
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Participants Modal */}
      <AnimatePresence>
        {showParticipants && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowParticipants(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 w-full max-w-2xl relative z-10 shadow-2xl flex flex-col max-h-[90vh]"
            >
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h3 className="text-2xl font-black text-white italic tracking-tighter">PARTICIPANTS</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{editingTournament?.title}</p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => {
                      const text = participants.map(p => `Name: ${p.ign} | UID: ${p.uid} | Level: ${p.level}`).join('\n');
                      navigator.clipboard.writeText(text);
                      alert('Participants list copied!');
                    }}
                    className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white text-[10px] font-bold uppercase tracking-widest rounded-xl transition-all"
                  >
                    Copy List
                  </button>
                  <button onClick={() => setShowParticipants(false)} className="p-2 hover:bg-gray-800 rounded-full">
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto custom-scrollbar pr-2">
                {loadingParticipants ? (
                  <div className="flex flex-col items-center justify-center py-20 gap-4">
                    <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
                    <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Loading Players...</p>
                  </div>
                ) : participants.length === 0 ? (
                  <div className="text-center py-20">
                    <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Users className="w-8 h-8 text-gray-600" />
                    </div>
                    <p className="text-gray-500 font-bold uppercase tracking-widest text-xs">No participants yet</p>
                  </div>
                ) : (
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-gray-800">
                        <th className="pb-4 text-[10px] font-black text-gray-500 uppercase tracking-widest">IGN / Name</th>
                        <th className="pb-4 text-[10px] font-black text-gray-500 uppercase tracking-widest">UID</th>
                        <th className="pb-4 text-[10px] font-black text-gray-500 uppercase tracking-widest">Level</th>
                        <th className="pb-4 text-[10px] font-black text-gray-500 uppercase tracking-widest">Joined At</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-800/50">
                      {participants.map((p, i) => (
                        <tr key={i} className="group">
                          <td className="py-4">
                            <p className="text-sm font-bold text-white uppercase tracking-tight">{p.ign}</p>
                          </td>
                          <td className="py-4">
                            <p className="text-sm font-mono text-gray-400 group-hover:text-blue-400 transition-colors">{p.uid}</p>
                          </td>
                          <td className="py-4">
                            <p className="text-sm font-bold text-gray-400">{p.level}</p>
                          </td>
                          <td className="py-4">
                            <p className="text-[10px] font-bold text-gray-600 uppercase">
                              {p.joinedAt ? format(new Date(p.joinedAt), 'p') : 'N/A'}
                            </p>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showCredentials && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCredentials(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 w-full max-w-sm relative z-10 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h3 className="text-2xl font-black text-white italic tracking-tighter">EDIT TOURNAMENT</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{editingTournament?.title}</p>
                </div>
                <button onClick={() => setShowCredentials(false)} className="p-2 hover:bg-gray-800 rounded-full">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleUpdateCredentials} className="space-y-6">
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Thumbnail</label>
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gray-950 border border-gray-800 rounded-2xl overflow-hidden flex items-center justify-center group relative">
                      {credData.thumbnail ? (
                        <>
                          <img src={credData.thumbnail} alt="Preview" className="w-full h-full object-cover" />
                          <button 
                            type="button"
                            onClick={() => setCredData({ ...credData, thumbnail: '' })}
                            className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-4 h-4 text-white" />
                          </button>
                        </>
                      ) : (
                        <Gamepad2 className="w-6 h-6 text-gray-800" />
                      )}
                    </div>
                    <div className="flex-1">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onloadend = () => {
                              setCredData({ ...credData, thumbnail: reader.result as string });
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                        className="hidden"
                        id="edit-thumbnail-upload"
                      />
                      <label 
                        htmlFor="edit-thumbnail-upload"
                        className="inline-block bg-gray-800 hover:bg-gray-700 text-white text-[8px] font-black uppercase tracking-widest py-2 px-4 rounded-xl cursor-pointer transition-all border border-gray-700"
                      >
                        Change
                      </label>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Room ID</label>
                  <input
                    required
                    type="text"
                    value={credData.roomId}
                    onChange={(e) => setCredData({ ...credData, roomId: e.target.value })}
                    className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    placeholder="Enter Room ID"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Room Password</label>
                  <input
                    required
                    type="text"
                    value={credData.roomPassword}
                    onChange={(e) => setCredData({ ...credData, roomPassword: e.target.value })}
                    className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    placeholder="Enter Room Password"
                  />
                </div>

                <button
                  type="submit"
                  disabled={updatingCreds}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-2xl shadow-xl shadow-blue-600/20 transition-all uppercase tracking-[0.2em] flex items-center justify-center gap-2"
                >
                  {updatingCreds ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Save Credentials'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showResultModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowResultModal(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 w-full max-w-sm relative z-10 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h3 className="text-2xl font-black text-white italic tracking-tighter">DECLARE RESULT</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{editingTournament?.title}</p>
                </div>
                <button onClick={() => setShowResultModal(false)} className="p-2 hover:bg-gray-800 rounded-full text-gray-500 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handlePublishResult} className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Winner Player ID (6-Digit)</label>
                    <input
                      type="text"
                      placeholder="e.g. 123456"
                      value={resultData.winnerProId}
                      onChange={(e) => setResultData({ ...resultData, winnerProId: e.target.value })}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    />
                  </div>

                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Select Winner Name</label>
                  
                  {editingTournament?.gameMode === 'Clash Squad' ? (
                    <select
                      value={resultData.winnerName}
                      onChange={(e) => setResultData({ ...resultData, winnerName: e.target.value })}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    >
                      <option value={editingTournament.team1Name || 'Team 1'}>{editingTournament.team1Name || 'Team 1'}</option>
                      <option value={editingTournament.team2Name || 'Team 2'}>{editingTournament.team2Name || 'Team 2'}</option>
                    </select>
                  ) : editingTournament?.gameMode === 'Lone Wolf' ? (
                    <select
                      value={resultData.winnerName}
                      onChange={(e) => setResultData({ ...resultData, winnerName: e.target.value })}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    >
                      <option value={editingTournament.player1Name || 'Player 1'}>{editingTournament.player1Name || 'Player 1'}</option>
                      <option value={editingTournament.player2Name || 'Player 2'}>{editingTournament.player2Name || 'Player 2'}</option>
                    </select>
                  ) : (
                    <div className="space-y-4">
                      <input
                        type="text"
                        placeholder="Winner Name / Team"
                        value={resultData.winnerName}
                        onChange={(e) => setResultData({ ...resultData, winnerName: e.target.value })}
                        className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                      />
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Total Kills</label>
                        <input
                          type="number"
                          value={resultData.winnerKills}
                          onChange={(e) => setResultData({ ...resultData, winnerKills: Number(e.target.value) })}
                          className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Prize Distributed ($)</label>
                  <input
                    type="number"
                    value={resultData.winnerPrize}
                    onChange={(e) => setResultData({ ...resultData, winnerPrize: Number(e.target.value) })}
                    className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                  />
                </div>

                <button
                  type="submit"
                  disabled={publishingResult}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-black py-5 rounded-2xl shadow-xl shadow-green-600/20 transition-all uppercase tracking-[0.2em] disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {publishingResult ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Publishing...
                    </>
                  ) : (
                    <>
                      <Trophy className="w-5 h-5" />
                      Publish Result
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
