import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, query, where, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { UserProfile, Transaction, Registration, Tournament } from '../../types';
import { 
  ArrowLeft, 
  CreditCard, 
  History, 
  Trophy, 
  ShieldCheck, 
  ShieldAlert, 
  Mail, 
  Gamepad2, 
  Calendar,
  DollarSign,
  Loader2,
  TrendingUp,
  TrendingDown,
  Clock
} from 'lucide-react';
import { formatCurrency, cn } from '../../lib/utils';
import { format } from 'date-fns';
import { motion } from 'motion/react';

export default function AdminUserDetails() {
  const { uid } = useParams();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [registrations, setRegistrations] = useState<(Registration & { tournament?: Tournament })[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!uid) return;

    const fetchData = async () => {
      try {
        // 1. Fetch Profile
        const userDoc = await getDoc(doc(db, 'users', uid));
        if (userDoc.exists()) {
          setProfile(userDoc.data() as UserProfile);
        }

        // 2. Fetch Transactions
        const tQuery = query(
          collection(db, 'transactions'),
          where('userId', '==', uid),
          orderBy('createdAt', 'desc')
        );
        const tSnap = await getDocs(tQuery);
        setTransactions(tSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));

        // 3. Fetch Registrations & Tournaments
        const rQuery = query(
          collection(db, 'registrations'),
          where('userId', '==', uid),
          orderBy('joinedAt', 'desc')
        );
        const rSnap = await getDocs(rQuery);
        const regs = rSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Registration));
        
        const regsWithTournaments = await Promise.all(regs.map(async (reg) => {
          const tDoc = await getDoc(doc(db, 'tournaments', reg.tournamentId));
          return { ...reg, tournament: tDoc.exists() ? { id: tDoc.id, ...tDoc.data() } as Tournament : undefined };
        }));
        
        setRegistrations(regsWithTournaments);

      } catch (err) {
        console.error("Error fetching user details:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [uid]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-40">
        <Loader2 className="w-12 h-12 animate-spin text-blue-500 mb-4" />
        <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Mapping User Data...</p>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center py-40">
        <ShieldAlert className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h2 className="text-2xl font-black text-white italic uppercase tracking-tighter">User Not Found</h2>
        <button onClick={() => navigate('/admin/users')} className="mt-6 text-blue-500 font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-2 mx-auto">
          <ArrowLeft className="w-4 h-4" /> Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-20">
      {/* Header */}
      <div className="flex items-center gap-6">
        <button 
          onClick={() => navigate('/admin/users')}
          className="p-4 bg-gray-900 border border-gray-800 rounded-2xl hover:bg-gray-800 transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-gray-400" />
        </button>
        <div>
          <h1 className="text-4xl font-black text-white italic tracking-tighter uppercase">{profile.displayName}</h1>
          <div className="flex items-center gap-4 mt-1">
            <div className="flex items-center gap-2 text-xs font-bold text-gray-500 uppercase tracking-widest">
              <Mail className="w-3 h-3" /> {profile.email}
            </div>
            <div className={cn(
              "flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest",
              profile.isBlocked ? "bg-red-500/10 text-red-500" : "bg-green-500/10 text-green-500"
            )}>
              {profile.isBlocked ? <ShieldAlert className="w-3 h-3" /> : <ShieldCheck className="w-3 h-3" />}
              {profile.isBlocked ? 'Blocked' : 'Active'}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Card & Stats */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 space-y-8 shadow-2xl">
            <div className="flex justify-center">
              <div className={cn(
                "w-24 h-24 rounded-[2rem] flex items-center justify-center text-4xl font-black italic border-2",
                profile.isBlocked ? "bg-red-600/10 border-red-500/20 text-red-500" : "bg-blue-600/20 border-blue-500/20 text-blue-500"
              )}>
                {profile.displayName[0].toUpperCase()}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-950 border border-gray-800 rounded-3xl p-5 text-center">
                <p className="text-[10px] font-bold text-gray-600 uppercase tracking-widest mb-1 italic">Deposits</p>
                <p className="text-xl font-black text-blue-500 italic tracking-tight">{formatCurrency(profile.balance.deposit)}</p>
              </div>
              <div className="bg-gray-950 border border-gray-800 rounded-3xl p-5 text-center">
                <p className="text-[10px] font-bold text-gray-600 uppercase tracking-widest mb-1 italic">Winnings</p>
                <p className="text-xl font-black text-green-500 italic tracking-tight">{formatCurrency(profile.balance.winning)}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-950 border border-gray-800 rounded-2xl">
                <div className="flex items-center gap-3">
                  <Gamepad2 className="w-4 h-4 text-gray-600" />
                  <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">In-Game ID</span>
                </div>
                <span className="text-xs font-mono text-white">{profile.gameId || 'NOT SET'}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-950 border border-gray-800 rounded-2xl">
                <div className="flex items-center gap-3">
                  <Calendar className="w-4 h-4 text-gray-600" />
                  <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Member Since</span>
                </div>
                <span className="text-xs font-bold text-white">{format(new Date(profile.createdAt), 'MMM dd, yyyy')}</span>
              </div>
            </div>

            {profile.paymentMethods && (
              <div className="space-y-4 pt-4 border-t border-gray-800">
                <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] italic">Saved Payment Methods</h4>
                {profile.paymentMethods.upi && (
                  <div className="flex items-center gap-3 p-4 bg-blue-600/5 border border-blue-500/10 rounded-2xl">
                    <CreditCard className="w-4 h-4 text-blue-500" />
                    <div>
                      <p className="text-[10px] font-bold text-gray-500 uppercase">UPI ID</p>
                      <p className="text-xs font-black text-white italic">{profile.paymentMethods.upi}</p>
                    </div>
                  </div>
                )}
                {profile.paymentMethods.bank && (
                  <div className="flex items-center gap-3 p-4 bg-purple-600/5 border border-purple-500/10 rounded-2xl">
                    <Trophy className="w-4 h-4 text-purple-500" />
                    <div>
                      <p className="text-[10px] font-bold text-gray-500 uppercase">Bank Account</p>
                      <p className="text-xs font-black text-white italic">{profile.paymentMethods.bank.accountNumber}</p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* History Tabs */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 shadow-2xl h-full">
            <div className="flex items-center gap-3 mb-8">
              <History className="w-6 h-6 text-blue-500" />
              <h3 className="text-2xl font-black text-white italic tracking-tighter uppercase">Activity Logs</h3>
            </div>

            <div className="space-y-8">
              {/* Recent Tournaments */}
              <div className="space-y-4">
                <h4 className="flex items-center gap-2 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">
                  <Trophy className="w-3 h-3" />
                  Recent Tournaments ({registrations.length})
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {registrations.slice(0, 4).map((reg) => (
                    <div key={reg.id} className="p-4 bg-gray-950 border border-gray-800 rounded-3xl group hover:border-blue-500/30 transition-all">
                      <div className="flex justify-between items-start mb-2">
                        <p className="text-sm font-black text-white uppercase tracking-tight italic line-clamp-1">{reg.tournament?.title || 'Unknown Match'}</p>
                        <span className={cn(
                          "text-[9px] font-bold px-2 py-0.5 rounded uppercase tracking-widest",
                          reg.status === 'registered' ? "bg-blue-600/10 text-blue-500" : "bg-red-600/10 text-red-500"
                        )}>
                          {reg.status}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-[10px] font-bold text-gray-600 uppercase tracking-widest">
                        <span className="flex items-center gap-1"><Gamepad2 className="w-3 h-3" /> {reg.tournament?.game}</span>
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {format(new Date(reg.joinedAt), 'MMM dd')}</span>
                      </div>
                    </div>
                  ))}
                  {registrations.length === 0 && <p className="text-xs text-gray-600 italic px-2">No matches joined yet.</p>}
                </div>
              </div>

              {/* Recent Transactions */}
              <div className="space-y-4">
                <h4 className="flex items-center gap-2 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">
                  <History className="w-3 h-3" />
                  Recent Transactions ({transactions.length})
                </h4>
                <div className="space-y-3">
                  {transactions.slice(0, 10).map((t) => (
                    <div key={t.id} className="flex items-center justify-between p-4 bg-gray-950 border border-gray-800 rounded-2xl hover:bg-gray-900 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className={cn(
                          "w-10 h-10 rounded-xl flex items-center justify-center",
                          t.type === 'deposit' || t.type === 'winning' ? "bg-green-600/10 text-green-500" : "bg-red-600/10 text-red-500"
                        )}>
                          {t.type === 'deposit' || t.type === 'winning' ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white uppercase tracking-widest">{t.description}</p>
                          <p className="text-[10px] text-gray-500 uppercase font-black tracking-tight">{format(new Date(t.createdAt), 'MMM dd, p')}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={cn(
                          "text-sm font-black italic",
                          t.type === 'deposit' || t.type === 'winning' ? "text-green-500" : "text-red-500"
                        )}>
                          {t.type === 'deposit' || t.type === 'winning' ? '+' : '-'}{formatCurrency(t.amount)}
                        </p>
                        <span className="text-[9px] font-bold text-gray-600 uppercase tracking-widest">{t.status}</span>
                      </div>
                    </div>
                  ))}
                  {transactions.length === 0 && <p className="text-xs text-gray-600 italic px-2">No transaction history found.</p>}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
