import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Transaction } from '../../types';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  Search, 
  Filter, 
  Download,
  CheckCircle2,
  XCircle,
  Clock
} from 'lucide-react';
import { formatCurrency, cn } from '../../lib/utils';
import { format } from 'date-fns';

export default function AdminTransactions() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'transactions'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snap) => {
      setTransactions(snap.docs.map(d => ({ id: d.id, ...d.data() } as Transaction)));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const filteredTransactions = transactions.filter(tx => 
    tx.userId.toLowerCase().includes(search.toLowerCase()) ||
    tx.type.toLowerCase().includes(search.toLowerCase()) ||
    tx.description?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 pb-20">
       <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-black text-white italic tracking-tighter">TRANSACTIONS</h1>
          <p className="text-gray-500 font-medium">Real-time ledger of all platform movements</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-3 bg-gray-900 border border-gray-800 rounded-2xl hover:bg-gray-800 transition-colors shadow-lg">
          <Download className="w-5 h-5 text-blue-500" />
          <span className="text-sm font-bold uppercase tracking-widest">Download Ledger</span>
        </button>
      </div>

      {/* Global Ledger Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Total Inflow', amount: transactions.filter(t => t.type === 'deposit').reduce((a, b) => a + b.amount, 0), color: 'text-green-500', icon: ArrowDownLeft },
          { label: 'Total Payouts', amount: transactions.filter(t => t.type === 'winning' || t.type === 'withdrawal').reduce((a, b) => a + b.amount, 0), color: 'text-red-500', icon: ArrowUpRight },
          { label: 'Platform Fees', amount: transactions.filter(t => t.type === 'entry_fee').reduce((a, b) => a + b.amount, 0), color: 'text-blue-500', icon: CheckCircle2 },
        ].map((stat, i) => (
          <div key={i} className="bg-gray-900 border border-gray-800 p-6 rounded-[2rem] flex items-center gap-6">
            <div className={cn("p-4 rounded-2xl bg-gray-950 border border-gray-800", stat.color)}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-1">{stat.label}</p>
              <h4 className="text-2xl font-black text-white italic">{formatCurrency(stat.amount)}</h4>
            </div>
          </div>
        ))}
      </div>

       {/* Search & Filter */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
          <input
            type="text"
            placeholder="Search by User ID, Transaction Type or Memo..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-gray-900 border border-gray-800 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
          />
        </div>
        <button className="px-6 py-4 bg-gray-900 border border-gray-800 rounded-2xl text-gray-400 hover:text-white flex items-center gap-2">
          <Filter className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs">Filter</span>
        </button>
      </div>

      {/* Transaction Table */}
       <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-800 bg-gray-950/50">
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Transaction ID</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Type</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">User ID</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Amount</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Status</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {filteredTransactions.map((tx) => (
                <tr key={tx.id} className="group hover:bg-gray-950/50 transition-colors">
                  <td className="px-8 py-6">
                    <p className="font-mono text-xs text-gray-400 group-hover:text-blue-500 transition-colors">{tx.id.substring(0, 12)}...</p>
                    <p className="text-[10px] text-gray-600 truncate max-w-[150px]">{tx.description || 'System generated'}</p>
                  </td>
                  <td className="px-8 py-6">
                    <span className={cn(
                      "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter",
                      tx.type === 'deposit' ? "bg-green-600/10 text-green-500" :
                      tx.type === 'entry_fee' ? "bg-red-600/10 text-red-500" :
                      tx.type === 'winning' ? "bg-blue-600/10 text-blue-500" :
                      "bg-yellow-600/10 text-yellow-500"
                    )}>
                      {tx.type.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-8 py-6">
                    <p className="text-xs font-medium text-gray-300">{tx.userId.substring(0, 8)}...</p>
                  </td>
                  <td className="px-8 py-6">
                    <p className={cn(
                      "font-black italic",
                      tx.type === 'deposit' || tx.type === 'winning' ? "text-green-500" : "text-red-500"
                    )}>
                      {tx.type === 'deposit' || tx.type === 'winning' ? '+' : '-'}{formatCurrency(tx.amount)}
                    </p>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-2">
                      {tx.status === 'success' ? (
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      ) : tx.status === 'failed' ? (
                        <XCircle className="w-4 h-4 text-red-500" />
                      ) : (
                        <Clock className="w-4 h-4 text-orange-500" />
                      )}
                      <span className="text-[10px] font-bold text-gray-500 uppercase italic">{tx.status}</span>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <p className="text-xs text-gray-400">{format(new Date(tx.createdAt), 'MMM dd, HH:mm')}</p>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
