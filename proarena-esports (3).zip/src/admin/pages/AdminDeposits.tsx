import React, { useState, useEffect } from 'react';
import { collection, query, where, orderBy, onSnapshot, doc, updateDoc, getDoc, runTransaction } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Transaction } from '../../types';
import { CheckCircle, XCircle, Clock, Search, Loader2, ArrowDownLeft } from 'lucide-react';
import { formatCurrency, cn } from '../../lib/utils';
import { format } from 'date-fns';

export default function AdminDeposits() {
  const [requests, setRequests] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const q = query(
      collection(db, 'transactions'),
      where('type', '==', 'deposit'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snap) => {
      setRequests(snap.docs.map(d => ({ id: d.id, ...d.data() } as Transaction)));
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleStatusUpdate = async (txId: string, newStatus: 'success' | 'failed', userId: string, amount: number) => {
    if (!confirm(`Are you sure you want to ${newStatus === 'success' ? 'APPROVE' : 'REJECT'} this deposit?`)) return;
    
    setProcessing(txId);
    try {
      if (newStatus === 'success') {
        // Atomic transaction to ensure balance is correctly updated
        await runTransaction(db, async (transaction) => {
          const userRef = doc(db, 'users', userId);
          const txRef = doc(db, 'transactions', txId);
          
          const userDoc = await transaction.get(userRef);
          if (!userDoc.exists()) throw new Error("User does not exist!");
          
          const txDoc = await transaction.get(txRef);
          if (!txDoc.exists()) throw new Error("Transaction does not exist!");
          if (txDoc.data().status !== 'pending') throw new Error("Transaction is no longer pending!");

          const currentDeposit = userDoc.data().balance?.deposit || 0;
          
          transaction.update(userRef, {
            'balance.deposit': currentDeposit + amount
          });
          
          transaction.update(txRef, { 
            status: 'completed',
            updatedAt: new Date().toISOString()
          });
        });
        alert('Deposit approved! User balance updated.');
      } else {
        // Just reject the transaction
        await updateDoc(doc(db, 'transactions', txId), {
          status: 'failed',
          updatedAt: new Date().toISOString()
        });
        alert('Deposit request rejected.');
      }
    } catch (err) {
      console.error('Update failed:', err);
      alert('Action failed: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setProcessing(null);
    }
  };

  const filteredRequests = requests.filter(r => 
    r.userId.toLowerCase().includes(search.toLowerCase()) ||
    (r.playerId && r.playerId.toLowerCase().includes(search.toLowerCase())) ||
    (r.id && r.id.toLowerCase().includes(search.toLowerCase())) ||
    (r.utr && r.utr.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-black text-white italic uppercase tracking-tighter">Deposit Requests</h1>
          <p className="text-gray-500 text-sm">Review and approve manual deposits</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gray-900 border border-gray-800 rounded-3xl p-6">
          <Clock className="w-8 h-8 text-yellow-500 mb-4" />
          <h3 className="text-2xl font-black text-white italic">
            {requests.filter(r => r.status === 'pending').length}
          </h3>
          <p className="text-[10px] uppercase font-bold text-gray-500 tracking-widest">Pending Requests</p>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-3xl p-6">
          <CheckCircle className="w-8 h-8 text-green-500 mb-4" />
          <h3 className="text-2xl font-black text-white italic">
            {requests.filter(r => r.status === 'completed' || r.status === 'success').length}
          </h3>
          <p className="text-[10px] uppercase font-bold text-gray-500 tracking-widest">Approved</p>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-3xl p-6 text-red-500">
          <ArrowDownLeft className="w-8 h-8 mb-4 opacity-50" />
          <h3 className="text-2xl font-black text-white italic">
            {formatCurrency(requests.filter(r => r.status === 'completed' || r.status === 'success').reduce((a, b) => a + b.amount, 0))}
          </h3>
          <p className="text-[10px] uppercase font-bold text-gray-500 tracking-widest">Total Deposited</p>
        </div>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="p-6 border-b border-gray-800 flex items-center justify-between">
          <h3 className="font-bold text-gray-300 uppercase text-xs tracking-widest">Recent Deposits</h3>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input 
              type="text" 
              placeholder="Search User ID..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-gray-950 border border-gray-800 rounded-xl py-2 pl-10 pr-4 text-xs text-white focus:outline-none focus:ring-1 focus:ring-blue-600"
            />
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-950 text-gray-500 text-[10px] uppercase tracking-widest font-bold">
                <th className="px-6 py-4">Transaction ID</th>
                <th className="px-6 py-4">Player ID</th>
                <th className="px-6 py-4">UTR Number</th>
                <th className="px-6 py-4">Amount</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {loading ? (
                Array(5).fill(0).map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={6} className="px-6 py-4 h-16 bg-gray-900/50"></td>
                  </tr>
                ))
              ) : filteredRequests.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-gray-500 text-sm italic">
                    No deposit requests found.
                  </td>
                </tr>
              ) : (
                filteredRequests.map((req) => (
                  <tr key={req.id} className="hover:bg-gray-800/50 transition-colors">
                    <td className="px-6 py-4 font-mono text-[10px] opacity-50">
                      {req.id.substring(0, 12)}...
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-white font-mono text-[10px]">{req.playerId || 'N/A'}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-blue-500 font-mono text-[10px] font-bold">{req.utr || 'N/A'}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-white font-black italic">{formatCurrency(req.amount)}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider",
                        req.status === 'pending' ? "bg-yellow-500/10 text-yellow-500" :
                        (req.status === 'completed' || req.status === 'success') ? "bg-green-500/10 text-green-500" :
                        "bg-red-500/10 text-red-500"
                      )}>
                        {req.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-400 text-[10px] font-bold uppercase tracking-widest">{format(new Date(req.createdAt), 'MMM dd | p')}</p>
                    </td>
                    <td className="px-6 py-4 text-right">
                      {req.status === 'pending' && (
                        <div className="flex justify-end gap-2 text-xs">
                          <button
                            onClick={() => handleStatusUpdate(req.id, 'success', req.userId, req.amount)}
                            disabled={processing === req.id}
                            className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl flex items-center gap-1 transition-all"
                          >
                            {processing === req.id ? <Loader2 className="w-3 h-3 animate-spin"/> : <CheckCircle className="w-3 h-3"/>}
                            Approve
                          </button>
                          <button
                            onClick={() => handleStatusUpdate(req.id, 'failed', req.userId, req.amount)}
                            disabled={processing === req.id}
                            className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-xl flex items-center gap-1 transition-all"
                          >
                            {processing === req.id ? <Loader2 className="w-3 h-3 animate-spin"/> : <XCircle className="w-3 h-3"/>}
                            Reject
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
