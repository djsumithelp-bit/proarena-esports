import React, { useEffect, useState } from 'react';
import { 
  collection, 
  onSnapshot, 
  query, 
  where, 
  getDocs,
  limit,
  orderBy,
  doc,
  updateDoc,
  writeBatch,
  deleteDoc
} from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { 
  Users, 
  Trophy, 
  DollarSign, 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight,
  Loader2,
  Gamepad2,
  CreditCard,
  Receipt,
  Zap,
  Trash2,
  RefreshCcw,
  ShieldAlert
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { useAuth } from '../../context/AuthContext';
import { formatCurrency, cn } from '../../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

const mockChartData = [
  { name: 'Mon', revenue: 4000 },
  { name: 'Tue', revenue: 3000 },
  { name: 'Wed', revenue: 2000 },
  { name: 'Thu', revenue: 2780 },
  { name: 'Fri', revenue: 1890 },
  { name: 'Sat', revenue: 2390 },
  { name: 'Sun', revenue: 3490 },
];

export default function AdminDashboard() {
  const { profile } = useAuth();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalTournaments: 0,
    totalRevenue: 0,
    pendingPayouts: 0,
    pendingDeposits: 0
  });
  const [loading, setLoading] = useState(true);
  const [resetting, setResetting] = useState(false);

  useEffect(() => {
    const unsubUsers = onSnapshot(collection(db, 'users'), (snap) => {
      setStats(prev => ({ ...prev, totalUsers: snap.size }));
    }, (error) => console.error("AdminDashboard users stats error:", error));

    const unsubTournaments = onSnapshot(collection(db, 'tournaments'), (snap) => {
      setStats(prev => ({ ...prev, totalTournaments: snap.size }));
    }, (error) => console.error("AdminDashboard tournaments stats error:", error));

    const unsubTransactions = onSnapshot(query(collection(db, 'transactions'), where('type', '==', 'deposit'), where('status', '==', 'success')), (snap) => {
      const total = snap.docs.reduce((acc, doc) => acc + (doc.data().amount || 0), 0);
      setStats(prev => ({ ...prev, totalRevenue: total }));
    }, (error) => console.error("AdminDashboard transactions stats error:", error));

    const unsubWithdrawals = onSnapshot(query(collection(db, 'transactions'), where('type', '==', 'withdrawal'), where('status', '==', 'pending')), (snap) => {
      setStats(prev => ({ ...prev, pendingPayouts: snap.size }));
    });

    const unsubDeposits = onSnapshot(query(collection(db, 'transactions'), where('type', '==', 'deposit'), where('status', '==', 'pending')), (snap) => {
      setStats(prev => ({ ...prev, pendingDeposits: snap.size }));
    });

    setLoading(false);
    return () => {
      unsubUsers();
      unsubTournaments();
      unsubTransactions();
      unsubWithdrawals();
      unsubDeposits();
    };
  }, []);

  const handleSystemReset = async (type: 'balances' | 'tournaments' | 'registrations' | 'revenue') => {
    const confirmMessage = type === 'balances' 
      ? 'DANGER: Reset ALL user balances (Deposit & Winnings) to $0? This CANNOT be undone.' 
      : type === 'tournaments' 
      ? 'DANGER: Delete ALL created tournaments? This will clear everything from the User Home screen.' 
      : type === 'registrations'
      ? 'DANGER: Clear ALL match registration entries? Participants lists will be emptied.'
      : 'DANGER: Are you sure you want to reset all earnings data? Total Earnings, Admin Profit, and Match Revenue will be cleared.';
      
    if (!confirm(confirmMessage)) return;

    setResetting(true);
    try {
      if (type === 'balances') {
        const usersSnap = await getDocs(collection(db, 'users'));
        const batch = writeBatch(db);
        usersSnap.docs.forEach(uDoc => {
          batch.update(uDoc.ref, { 
            balance: { deposit: 0, winning: 0 } 
          });
        });
        await batch.commit();
        alert('All user balances have been reset to 0.');
      } else if (type === 'tournaments') {
        const tSnap = await getDocs(collection(db, 'tournaments'));
        for (const tDoc of tSnap.docs) {
          // Delete all registration sub-docs first
          const rSnap = await getDocs(collection(db, 'tournaments', tDoc.id, 'registrations'));
          const rBatch = writeBatch(db);
          rSnap.docs.forEach(rDoc => rBatch.delete(rDoc.ref));
          await rBatch.commit();
          // Delete tournament
          await deleteDoc(tDoc.ref);
        }
        alert('All tournaments and their registrations were deleted.');
      } else if (type === 'registrations') {
        const tSnap = await getDocs(collection(db, 'tournaments'));
        for (const tDoc of tSnap.docs) {
          const rSnap = await getDocs(collection(db, 'tournaments', tDoc.id, 'registrations'));
          const rBatch = writeBatch(db);
          rSnap.docs.forEach(rDoc => rBatch.delete(rDoc.ref));
          await rBatch.commit();
          // Reset playersCount to 0
          await updateDoc(tDoc.ref, { playersCount: 0 });
        }
        alert('All match registrations have been cleared.');
      } else if (type === 'revenue') {
        // Clear all revenue-related transactions (deposits, entries, winnings)
        const transSnap = await getDocs(collection(db, 'transactions'));
        const batchSize = 500;
        let batch = writeBatch(db);
        let count = 0;

        for (const tDoc of transSnap.docs) {
          batch.delete(tDoc.ref);
          count++;
          if (count === batchSize) {
            await batch.commit();
            batch = writeBatch(db);
            count = 0;
          }
        }
        if (count > 0) await batch.commit();
        
        alert('Revenue tracking has been reset. All transaction history cleared.');
      }
    } catch (err) {
      console.error(err);
      alert('Operation failed. Check logs.');
    } finally {
      setResetting(false);
    }
  };

  const cards = [
    { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'bg-blue-600', trend: '+12%', positive: true, path: '/admin/users' },
    { label: 'Revenue', value: formatCurrency(stats.totalRevenue), icon: DollarSign, color: 'bg-green-600', trend: '+8%', positive: true, path: '/admin/transactions' },
    { label: 'Pending Deposits', value: stats.pendingDeposits, icon: Zap, color: 'bg-yellow-600', trend: stats.pendingDeposits > 0 ? 'ACTION' : 'CLEAR', positive: stats.pendingDeposits === 0, path: '/admin/deposits' },
    { label: 'Pending Payouts', value: stats.pendingPayouts, icon: CreditCard, color: 'bg-red-600', trend: stats.pendingPayouts > 0 ? 'CRITICAL' : 'ALL CLEAR', positive: stats.pendingPayouts === 0, path: '/admin/withdrawals' },
  ];

  if (loading) return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-blue-500 w-10 h-10" /></div>;

  return (
    <div className="space-y-8 pb-20">
      <div className="flex justify-between items-end">
        <div>
          <h3 className="text-gray-400 text-sm font-bold uppercase tracking-widest mb-1">Platform Control Room</h3>
          <h1 className="text-4xl font-black text-white italic tracking-tighter uppercase">Overview</h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 bg-green-600/10 border border-green-500/20 rounded-xl">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-[10px] font-black text-green-500 uppercase tracking-widest">Live Sync</span>
          </div>
          <button 
            onClick={() => window.location.href = '/'}
            className="bg-gray-900 border border-gray-800 px-4 py-2 rounded-xl text-xs font-bold text-gray-400 hover:text-white transition-all flex items-center gap-2"
          >
            <ArrowUpRight className="w-4 h-4" />
            Exit Admin
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            onClick={() => window.location.href = card.path}
            className="bg-gray-900 border border-gray-800 p-6 rounded-[2rem] hover:border-blue-500/50 transition-all group cursor-pointer relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full -translate-y-12 translate-x-12 blur-2xl group-hover:bg-white/10 transition-colors"></div>
            <div className="flex justify-between items-start mb-4 relative z-10">
              <div className={cn("p-3 rounded-2xl shadow-lg shadow-black/20", card.color)}>
                <card.icon className="w-6 h-6 text-white" />
              </div>
              <div className={cn(
                "flex items-center gap-1 text-[8px] font-black uppercase tracking-widest px-2 py-1 rounded-lg border",
                card.positive ? "border-green-500/20 text-green-500 bg-green-500/5" : "border-red-500/20 text-red-500 bg-red-500/5 animate-pulse"
              )}>
                {card.trend}
              </div>
            </div>
            <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest relative z-10">{card.label}</p>
            <h4 className="text-3xl font-black text-white mt-1 group-hover:translate-x-2 transition-transform origin-left relative z-10 italic tracking-tighter">
              {card.value}
            </h4>
          </motion.div>
        ))}
      </div>

      {/* System Maintenance & Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Maintenance Tools - Only for Admin+ */}
        {(profile?.role === 'admin' || profile?.role === 'super_admin') && (
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-600/5 blur-3xl -translate-x-4 -translate-y-4"></div>
              <h3 className="text-xl font-black text-white italic tracking-tighter uppercase mb-6 flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-yellow-500" />
                Maintenance Console
              </h3>
              <div className="space-y-4">
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1 mb-2">Platform Cleanup</p>
                  <div className="grid gap-3">
                    <button 
                      onClick={() => handleSystemReset('tournaments')}
                      disabled={resetting}
                      className="w-full py-4 bg-red-600/10 border border-red-500/20 text-red-500 hover:bg-red-600/20 rounded-2xl transition-all font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 disabled:opacity-50"
                    >
                      {resetting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                      Delete All Tournaments
                    </button>
                    <button 
                      onClick={() => handleSystemReset('registrations')}
                      disabled={resetting}
                      className="w-full py-4 bg-orange-600/10 border border-orange-500/20 text-orange-500 hover:bg-orange-600/20 rounded-2xl transition-all font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 disabled:opacity-50"
                    >
                      {resetting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                      Clear All Registrations
                    </button>
                  </div>
                </div>

                <div className="h-px bg-gray-800 my-4" />

                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1 mb-2">Financial Tools</p>
                  <div className="grid gap-3">
                    <button 
                      onClick={() => handleSystemReset('balances')}
                      disabled={resetting}
                      className="w-full py-4 bg-blue-600/10 border border-blue-500/20 text-blue-500 hover:bg-blue-600/20 rounded-2xl transition-all font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 disabled:opacity-50"
                    >
                      {resetting ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCcw className="w-4 h-4" />}
                      Global Balance Reset
                    </button>
                    <button 
                      onClick={() => handleSystemReset('revenue')}
                      disabled={resetting}
                      className="w-full py-4 bg-red-600/10 border border-red-500/20 text-red-500 hover:bg-red-600/20 rounded-2xl transition-all font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 disabled:opacity-50"
                    >
                      {resetting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                      Reset Revenue History
                    </button>
                  </div>
                </div>
              </div>
              <div className="mt-6 p-4 bg-gray-950/50 rounded-2xl border border-gray-800/50">
                <p className="text-[8px] text-gray-600 font-bold uppercase tracking-widest leading-relaxed">
                  <span className="text-yellow-600">WARNING:</span> Actions performed here directly modify the live production database. Use with extreme caution during match hours.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Chart Section */}
        <div className={cn(
          "bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 relative overflow-hidden",
          (profile?.role === 'admin' || profile?.role === 'super_admin') ? "lg:col-span-2" : "lg:col-span-3"
        )}>
          <div className="flex justify-between items-center mb-8">
            <div>
              <h3 className="text-xl font-bold text-white uppercase tracking-tighter italic">Platform Traffic</h3>
              <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest">Performance Analytics</p>
            </div>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockChartData}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
                <XAxis dataKey="name" stroke="#6b7280" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#6b7280" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#111827', border: '1px solid #1f2937', borderRadius: '12px', fontSize: '10px' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#2563eb" fillOpacity={1} fill="url(#colorRev)" strokeWidth={4} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-20">
        <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8">
          <h3 className="text-xl font-bold text-white mb-8 italic uppercase tracking-tighter">Popular Games</h3>
          <div className="space-y-6">
            {[
              { name: 'BGMI', count: 120, color: 'bg-blue-500' },
              { name: 'Free Fire', count: 85, color: 'bg-orange-500' },
              { name: 'COD Mobile', count: 64, color: 'bg-green-500' },
            ].map((game) => (
              <div key={game.name} className="space-y-2">
                <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest">
                  <span className="text-gray-300">{game.name}</span>
                  <span className="text-gray-500">{game.count} Users</span>
                </div>
                <div className="h-2 bg-gray-950 rounded-full overflow-hidden border border-gray-800/50">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(game.count / 120) * 100}%` }}
                    className={cn("h-full rounded-full shadow-lg shadow-black", game.color)}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 flex flex-col justify-center items-center text-center space-y-4">
          <div className="w-16 h-16 rounded-3xl bg-blue-600/10 flex items-center justify-center border border-blue-500/20 mb-2">
            <Trophy className="w-8 h-8 text-blue-500" />
          </div>
          <h3 className="text-xl font-black text-white italic tracking-tighter uppercase">Total Prize Awarded</h3>
          <p className="text-4xl font-black text-green-500 italic">$12,450.00</p>
          <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">All time payout history</p>
        </div>
      </div>
    </div>
  );
}
