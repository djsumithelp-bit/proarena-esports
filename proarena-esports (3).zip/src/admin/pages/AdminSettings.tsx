import React, { useEffect, useState } from 'react';
import { doc, onSnapshot, updateDoc, setDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { AppSettings } from '../../types';
import { 
  Settings, 
  ShieldAlert, 
  Power, 
  MessageSquare, 
  Save, 
  Loader2,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../../lib/utils';

export default function AdminSettings() {
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<{ message: string, type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'app'), (snap) => {
      if (snap.exists()) {
        setSettings(snap.data() as AppSettings);
      } else {
        // Init settings if they don't exist
        const initial: AppSettings = {
          isMaintenance: false,
          maintenanceMessage: "We'll be back soon!",
          version: "1.0.0"
        };
        setDoc(doc(db, 'settings', 'app'), initial);
      }
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const handleToggleMaintenance = async () => {
    if (!settings) return;
    setSaving(true);
    try {
      await updateDoc(doc(db, 'settings', 'app'), {
        isMaintenance: !settings.isMaintenance
      });
      setToast({ 
        message: `Maintenance Mode ${!settings.isMaintenance ? 'ACTIVATED' : 'DEACTIVATED'}`, 
        type: 'success' 
      });
    } catch (err) {
      console.error(err);
      setToast({ message: "Update failed", type: 'error' });
    } finally {
      setSaving(false);
      setTimeout(() => setToast(null), 3000);
    }
  };

  const handleUpdateMessage = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    const formData = new FormData(e.currentTarget);
    const message = formData.get('message') as string;
    
    try {
      await updateDoc(doc(db, 'settings', 'app'), {
        maintenanceMessage: message
      });
      setToast({ message: "Message updated successfully", type: 'success' });
    } catch (err) {
      console.error(err);
      setToast({ message: "Update failed", type: 'error' });
    } finally {
      setSaving(false);
      setTimeout(() => setToast(null), 3000);
    }
  };

  const handleUpdatePayment = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    const formData = new FormData(e.currentTarget);
    const upiId = formData.get('upiId') as string;
    const qrCodeUrl = formData.get('qrCodeUrl') as string;
    
    try {
      await updateDoc(doc(db, 'settings', 'app'), {
        upiId,
        qrCodeUrl
      });
      setToast({ message: "Payment settings updated", type: 'success' });
    } catch (err) {
      console.error(err);
      setToast({ message: "Update failed", type: 'error' });
    } finally {
      setSaving(false);
      setTimeout(() => setToast(null), 3000);
    }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-blue-500 w-10 h-10" /></div>;

  return (
    <div className="space-y-8 pb-20 max-w-4xl">
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: -50, x: '-50%' }}
            animate={{ opacity: 1, y: 20, x: '-50%' }}
            exit={{ opacity: 0, y: -50, x: '-50%' }}
            className={cn(
              "fixed top-4 left-1/2 z-[1000] px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border",
              toast.type === 'success' ? "bg-green-600 border-green-500 text-white" : "bg-red-600 border-red-500 text-white"
            )}
          >
            {toast.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <ShieldAlert className="w-5 h-5" />}
            <span className="text-xs font-bold uppercase tracking-widest">{toast.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div>
        <h3 className="text-gray-400 text-sm font-bold uppercase tracking-widest mb-1">Global Configuration</h3>
        <h1 className="text-4xl font-black text-white italic tracking-tighter uppercase">Platform Settings</h1>
      </div>

      <div className="grid gap-8">
        {/* Payment Settings */}
        <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 shadow-xl">
          <div className="flex items-center gap-3 mb-8">
            <div className="p-3 rounded-2xl bg-blue-600/20 border border-blue-500/20 text-blue-500">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-black text-white italic uppercase tracking-tight">Payment Settings</h3>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Configure UPI ID and QR Code for Deposits</p>
            </div>
          </div>

          <form onSubmit={handleUpdatePayment} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Merchant UPI ID</label>
                <input 
                  name="upiId"
                  type="text" 
                  defaultValue={settings?.upiId || ''}
                  className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-6 text-white text-sm font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  placeholder="e.g. 8889040032@ybl"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">QR Code Image URL</label>
                <input 
                  name="qrCodeUrl"
                  type="text" 
                  defaultValue={settings?.qrCodeUrl || ''}
                  className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-6 text-white text-sm font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  placeholder="Paste direct link to QR image"
                  required
                />
              </div>
            </div>
            
            <div className="flex justify-end pt-2">
              <button 
                type="submit"
                disabled={saving}
                className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all shadow-xl shadow-blue-600/20 flex items-center gap-2"
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                Save Payment Settings
              </button>
            </div>
          </form>
        </div>

        {/* Maintenance Toggle */}
        <div className={cn(
          "bg-gray-900 border rounded-[2.5rem] p-8 transition-all duration-500",
          settings?.isMaintenance ? "border-red-500/50 shadow-2xl shadow-red-600/10" : "border-gray-800"
        )}>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "p-3 rounded-2xl border",
                  settings?.isMaintenance ? "bg-red-600/20 border-red-500/20 text-red-500" : "bg-gray-800 border-gray-700 text-gray-400"
                )}>
                  <Power className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-white italic uppercase tracking-tight">Maintenance Mode</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Toggle app access for all users</p>
                </div>
              </div>
            </div>
            
            <button 
              onClick={handleToggleMaintenance}
              disabled={saving}
              className={cn(
                "px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-3 transition-all",
                settings?.isMaintenance 
                  ? "bg-red-600 text-white shadow-xl shadow-red-600/20 hover:bg-red-700" 
                  : "bg-gray-950 border border-gray-800 text-gray-400 hover:text-white"
              )}
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Power className="w-4 h-4" />}
              {settings?.isMaintenance ? 'Turn OFF Maintenance' : 'Turn ON Maintenance'}
            </button>
          </div>

          {settings?.isMaintenance && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              className="mt-8 pt-8 border-t border-red-500/10 space-y-6"
            >
              <div className="bg-red-600/5 border border-red-500/20 rounded-3xl p-6 flex gap-4">
                <AlertTriangle className="w-6 h-6 text-red-500 shrink-0" />
                <div>
                  <p className="text-xs font-black text-red-500 uppercase tracking-widest mb-1 italic">Active Warning</p>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest leading-relaxed">
                    The user application is currently locked. Users will see the maintenance screen. Only the Admin Panel remains accessible.
                  </p>
                </div>
              </div>

              <form onSubmit={handleUpdateMessage} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Custom Maintenance Message</label>
                  <div className="flex gap-4">
                    <div className="flex-1 relative">
                      <MessageSquare className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
                      <input 
                        name="message"
                        type="text" 
                        defaultValue={settings.maintenanceMessage}
                        className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 pl-12 pr-4 text-white text-sm font-bold focus:outline-none focus:ring-2 focus:ring-red-500/50"
                        placeholder="Enter message for users..."
                      />
                    </div>
                    <button 
                      type="submit"
                      disabled={saving}
                      className="px-6 py-4 bg-gray-950 border border-gray-800 rounded-2xl text-white font-black text-xs uppercase tracking-widest hover:border-blue-500 transition-all flex items-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      Save
                    </button>
                  </div>
                </div>
              </form>
            </motion.div>
          )}
        </div>

        {/* Other Configs Placeholder */}
        <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 opacity-50 cursor-not-allowed">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 rounded-2xl bg-gray-800 text-gray-400">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-black text-white italic uppercase tracking-tight">System Version</h3>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest underline">Core Updates (Coming Soon)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
