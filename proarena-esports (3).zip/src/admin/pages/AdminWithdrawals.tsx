import React, { useState, useEffect } from 'react';
import { collection, query, where, orderBy, onSnapshot, doc, updateDoc, getDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Transaction } from '../../types';
import { CreditCard, CheckCircle, XCircle, Clock, Search, Loader2 } from 'lucide-react';
import { formatCurrency, cn } from '../../lib/utils';
import { format } from 'date-fns';

export default function AdminWithdrawals() {
  const [requests, setRequests] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState<string | null>(null);

  useEffect(() => {
    const q = query(
      collection(db, 'transactions'),
      where('type', '==', 'withdrawal'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snap) => {
      setRequests(snap.docs.map(d => ({ id: d.id, ...d.data() } as Transaction)));
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleStatusUpdate = async (txId: string, newStatus: 'success' | 'failed', userId: string, amount: number) => {
    setProcessing(txId);
    try {
      const txRef = doc(db, 'transactions', txId);
      
      if (newStatus === 'failed') {
        // Refund the user if the withdrawal is rejected
        const userRef = doc(db, 'users', userId);
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          const userData = userSnap.data();
          await updateDoc(userRef, {
            'balance.winning': (userData.balance?.winning || 0) + amount
          });
        }
      }

      await updateDoc(txRef, { 
        status: newStatus,
        updatedAt: new Date().toISOString()
      });
      
      alert(`Withdrawal ${newStatus === 'success' ? 'Approved' : 'Rejected'} successfully.`);
    } catch (err) {
      console.error('Update failed:', err);
      alert('Action failed. Check console.');
    } finally {
      setProcessing(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-black text-white italic uppercase tracking-tighter">Withdrawal Requests</h1>
          <p className="text-gray-500 text-sm">Manage user payout requests</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gray-900 border border-gray-800 rounded-3xl p-6">
          <Clock className="w-8 h-8 text-yellow-500 mb-4" />
          <h3 className="text-2xl font-black text-white italic">
            {requests.filter(r => r.status === 'pending').length}
          </h3>
          <p className="text-[10px] uppercase font-bold text-gray-500 tracking-widest">Pending Requests</p>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-3xl p-6">
          <CheckCircle className="w-8 h-8 text-green-500 mb-4" />
          <h3 className="text-2xl font-black text-white italic">
            {requests.filter(r => r.status === 'success').length}
          </h3>
          <p className="text-[10px] uppercase font-bold text-gray-500 tracking-widest">Completed</p>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-3xl p-6">
          <XCircle className="w-8 h-8 text-red-500 mb-4" />
          <h3 className="text-2xl font-black text-white italic">
            {requests.filter(r => r.status === 'failed').length}
          </h3>
          <p className="text-[10px] uppercase font-bold text-gray-500 tracking-widest">Rejected</p>
        </div>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="p-6 border-b border-gray-800 flex items-center justify-between">
          <h3 className="font-bold text-gray-300 uppercase text-xs tracking-widest">Recent Requests</h3>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input 
              type="text" 
              placeholder="Search UI ID..." 
              className="bg-gray-950 border border-gray-800 rounded-xl py-2 pl-10 pr-4 text-xs text-white focus:outline-none focus:ring-1 focus:ring-blue-600"
            />
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-950 text-gray-500 text-[10px] uppercase tracking-widest font-bold">
                <th className="px-6 py-4">User & Method</th>
                <th className="px-6 py-4">Details</th>
                <th className="px-6 py-4">Amount</th>
                <th className="px-6 py-4">Requested At</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {loading ? (
                Array(5).fill(0).map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={6} className="px-6 py-4 h-16 bg-gray-900/50"></td>
                  </tr>
                ))
              ) : requests.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-gray-500 text-sm italic">
                    No withdrawal requests found.
                  </td>
                </tr>
              ) : (
                requests.map((req) => (
                  <tr key={req.id} className="hover:bg-gray-800/50 transition-colors">
                    <td className="px-6 py-4">
                      <p className="text-white font-mono text-[10px] opacity-50 mb-1">{req.userId}</p>
                      <span className="bg-blue-600/10 text-blue-500 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-widest">
                        {req.paymentMethod || 'Unknown'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-300 font-bold text-xs">{req.paymentDetails || 'N/A'}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-white font-black italic">{formatCurrency(req.amount)}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-400 text-[10px] font-bold uppercase tracking-widest">{format(new Date(req.createdAt), 'MMM dd | p')}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider",
                        req.status === 'pending' ? "bg-yellow-500/10 text-yellow-500" :
                        req.status === 'success' ? "bg-green-500/10 text-green-500" :
                        "bg-red-500/10 text-red-500"
                      )}>
                        {req.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      {req.status === 'pending' && (
                        <div className="flex justify-end gap-2 text-xs">
                          <button
                            onClick={() => handleStatusUpdate(req.id, 'success', req.userId, req.amount)}
                            disabled={processing === req.id}
                            className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-3 rounded-xl flex items-center gap-1 transition-all"
                          >
                            {processing === req.id ? <Loader2 className="w-3 h-3 animate-spin"/> : <CheckCircle className="w-3 h-3"/>}
                            Approve
                          </button>
                          <button
                            onClick={() => handleStatusUpdate(req.id, 'failed', req.userId, req.amount)}
                            disabled={processing === req.id}
                            className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-3 rounded-xl flex items-center gap-1 transition-all"
                          >
                            {processing === req.id ? <Loader2 className="w-3 h-3 animate-spin"/> : <XCircle className="w-3 h-3"/>}
                            Reject
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
