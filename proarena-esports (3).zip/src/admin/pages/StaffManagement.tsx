import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, getDocs, limit } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { UserProfile, UserRole } from '../../types';
import { 
  ShieldAlert, 
  UserPlus, 
  Search, 
  Trash2, 
  ShieldCheck, 
  Shield, 
  Loader2,
  Mail,
  User,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function StaffManagement() {
  const [staff, setStaff] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchEmail, setSearchEmail] = useState('');
  const [foundUser, setFoundUser] = useState<UserProfile | null>(null);
  const [searching, setSearching] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [toast, setToast] = useState<{ message: string, type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    // Listen to all staff members
    const q = query(
      collection(db, 'users'), 
      where('role', 'in', ['moderator', 'support', 'admin', 'super_admin'])
    );
    const unsub = onSnapshot(q, (snap) => {
      setStaff(snap.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile)));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchEmail) return;
    setSearching(true);
    setFoundUser(null);
    try {
      const q = query(collection(db, 'users'), where('email', '==', searchEmail.toLowerCase()), limit(1));
      const snap = await getDocs(q);
      if (!snap.empty) {
        setFoundUser({ uid: snap.docs[0].id, ...snap.docs[0].data() } as UserProfile);
      } else {
        showToast("User not found in database", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Searching failed", "error");
    } finally {
      setSearching(false);
    }
  };

  const handlePromote = async (role: UserRole) => {
    if (!foundUser) return;
    setUpdating(true);
    try {
      await updateDoc(doc(db, 'users', foundUser.uid), { role });
      showToast(`${foundUser.displayName} promoted to ${role}`);
      setFoundUser(null);
      setSearchEmail('');
    } catch (err) {
      console.error(err);
      showToast("Promotion failed", "error");
    } finally {
      setUpdating(false);
    }
  };

  const handleRevoke = async (user: UserProfile) => {
    if (user.role === 'super_admin') {
      showToast("Cannot revoke Super Admin access", "error");
      return;
    }
    if (!confirm(`Revoke all administrative access for ${user.displayName}?`)) return;
    
    setUpdating(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), { role: 'user' });
      showToast(`Access revoked for ${user.displayName}`);
    } catch (err) {
      console.error(err);
      showToast("Action failed", "error");
    } finally {
      setUpdating(false);
    }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-blue-500 w-10 h-10" /></div>;

  return (
    <div className="space-y-8 pb-20">
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: -50, x: '-50%' }}
            animate={{ opacity: 1, y: 20, x: '-50%' }}
            exit={{ opacity: 0, y: -50, x: '-50%' }}
            className={cn(
              "fixed top-4 left-1/2 z-[1000] px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border",
              toast.type === 'success' ? "bg-green-600 border-green-500 text-white" : "bg-red-600 border-red-500 text-white"
            )}
          >
            {toast.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <ShieldAlert className="w-5 h-5" />}
            <span className="text-xs font-bold uppercase tracking-widest">{toast.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div>
        <h3 className="text-gray-400 text-sm font-bold uppercase tracking-widest mb-1">Administrative Hierarchy</h3>
        <h1 className="text-4xl font-black text-white italic tracking-tighter uppercase">Staff Management</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Hire Section */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 shadow-2xl">
            <h3 className="text-xl font-black text-white italic uppercase tracking-tight mb-6 flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-blue-500" />
              Hire New Staff
            </h3>
            
            <form onSubmit={handleSearch} className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Search User by Email</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
                  <input 
                    type="email"
                    value={searchEmail}
                    onChange={(e) => setSearchEmail(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 pl-12 pr-4 text-white text-sm font-bold focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    placeholder="staff@example.com"
                  />
                </div>
              </div>
              <button 
                type="submit"
                disabled={searching || !searchEmail}
                className="w-full py-4 bg-gray-950 border border-gray-800 hover:border-blue-500 text-white font-black text-[10px] uppercase tracking-[0.2em] rounded-2xl transition-all flex items-center justify-center gap-2"
              >
                {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                Locate User
              </button>
            </form>

            <AnimatePresence>
              {foundUser && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-8 p-6 bg-gray-950 border border-gray-800 rounded-3xl space-y-6"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-blue-600/20 flex items-center justify-center text-blue-500 font-black italic border border-blue-500/20">
                      {foundUser.displayName[0].toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-black text-white uppercase tracking-tight">{foundUser.displayName}</p>
                      <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest leading-none">{foundUser.role}</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Assign Role</p>
                    <div className="grid grid-cols-1 gap-2">
                      {[
                        { role: 'moderator', label: 'Moderator', desc: 'Manage Matches' },
                        { role: 'support', label: 'Support', desc: 'Finance & Users' },
                        { role: 'admin', label: 'Full Admin', desc: 'Platform Access' }
                      ].map((item) => (
                        <button
                          key={item.role}
                          onClick={() => handlePromote(item.role as UserRole)}
                          disabled={updating}
                          className="flex items-center justify-between p-4 bg-gray-900 border border-gray-800 rounded-2xl hover:border-blue-500 transition-all group"
                        >
                          <div className="text-left">
                            <p className="text-xs font-black text-white uppercase tracking-widest">{item.label}</p>
                            <p className="text-[9px] text-gray-500 font-bold uppercase">{item.desc}</p>
                          </div>
                          <ShieldCheck className="w-4 h-4 text-gray-600 group-hover:text-blue-500" />
                        </button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Staff List */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 shadow-2xl">
            <h3 className="text-xl font-black text-white italic uppercase tracking-tight mb-8 flex items-center gap-2">
              <Shield className="w-5 h-5 text-green-500" />
              Active Staff ({staff.length})
            </h3>

            <div className="space-y-4">
              {staff.map((member) => (
                <div key={member.uid} className="flex flex-col md:flex-row md:items-center justify-between p-6 bg-gray-950 border border-gray-800 rounded-3xl hover:bg-gray-900 transition-all gap-6">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-black italic border",
                      member.role === 'super_admin' ? "bg-yellow-600/10 border-yellow-500/20 text-yellow-500" : "bg-blue-600/10 border-blue-500/20 text-blue-500"
                    )}>
                      {member.displayName[0].toUpperCase()}
                    </div>
                    <div>
                      <p className="font-black text-white uppercase tracking-tight italic">{member.displayName}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={cn(
                          "px-2 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-widest border",
                          member.role === 'super_admin' ? "bg-yellow-600/20 border-yellow-500/20 text-yellow-500" : "bg-blue-600/20 border-blue-500/20 text-blue-500"
                        )}>
                          {member.role.replace('_', ' ')}
                        </span>
                        <span className="text-[10px] text-gray-500 font-bold lowercase">{member.email}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {member.role !== 'super_admin' ? (
                      <button 
                        onClick={() => handleRevoke(member)}
                        disabled={updating}
                        className="px-6 py-3 bg-red-600/10 border border-red-500/20 text-red-500 hover:bg-red-600/20 rounded-xl transition-all font-black text-[10px] uppercase tracking-widest flex items-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        Revoke Access
                      </button>
                    ) : (
                      <div className="px-6 py-3 bg-yellow-600/10 border border-yellow-500/20 text-yellow-500 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4" />
                        Platform Owner
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {staff.length === 0 && (
                <div className="text-center py-20">
                  <ShieldAlert className="w-12 h-12 text-gray-800 mx-auto mb-4" />
                  <p className="text-gray-600 font-bold uppercase tracking-widest text-xs">No administrative staff found</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
