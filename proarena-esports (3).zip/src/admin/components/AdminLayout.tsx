import React from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Trophy, 
  Receipt, 
  LogOut, 
  ChevronRight,
  ShieldCheck,
  Menu,
  X,
  CreditCard,
  Landmark,
  Settings as SettingsIcon,
  ShieldAlert
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { cn } from '../../lib/utils';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { UserRole } from '../../types';

export default function AdminLayout() {
  const { user, signOut, profile } = useAuth();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const isSystemAdmin = user?.email === 'sumitdhakad4424@gmail.com';
  const role = isSystemAdmin ? 'super_admin' : (profile?.role || 'user');

  const navItems = [
    { path: '/admin', icon: LayoutDashboard, label: 'Dashboard', roles: ['moderator', 'support', 'admin', 'super_admin'] },
    { path: '/admin/users', icon: Users, label: 'User Management', roles: ['support', 'admin', 'super_admin'] },
    { path: '/admin/tournaments', icon: Trophy, label: 'Match Management', roles: ['moderator', 'admin', 'super_admin'] },
    { path: '/admin/deposits', icon: Landmark, label: 'Deposit Requests', roles: ['support', 'admin', 'super_admin'] },
    { path: '/admin/transactions', icon: Receipt, label: 'Revenue', roles: ['admin', 'super_admin'] },
    { path: '/admin/withdrawals', icon: CreditCard, label: 'Withdrawal Requests', roles: ['support', 'admin', 'super_admin'] },
    { path: '/admin/staff', icon: ShieldCheck, label: 'Staff Management', roles: ['admin', 'super_admin'] },
    { path: '/admin/settings', icon: SettingsIcon, label: 'Settings', roles: ['admin', 'super_admin'] },
  ].filter(item => item.roles.includes(role));

  return (
    <div className="min-h-screen bg-gray-950 text-white flex">
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside 
        className={cn(
          "fixed inset-y-0 left-0 z-[70] bg-gray-900 border-r border-gray-800 transition-all duration-500 ease-in-out transform",
          isSidebarOpen ? "w-72 translate-x-0" : "-translate-x-full lg:translate-x-0 lg:w-24 xl:w-72"
        )}
      >
        <div className="h-full flex flex-col">
          {/* Logo Section */}
          <div className="p-8 flex items-center justify-between">
            <div className={cn("flex items-center gap-3 transition-all", !isSidebarOpen && "lg:opacity-0 xl:opacity-100")}>
              <div className="w-10 h-10 rounded-2xl bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-600/20">
                <Trophy className="w-6 h-6 text-white" />
              </div>
              <span className="font-black text-2xl tracking-tighter italic uppercase font-display">
                PRO<span className="text-blue-500">ARENA</span>
              </span>
            </div>
            <button 
              onClick={() => setIsSidebarOpen(false)}
              className="p-2 hover:bg-gray-800 rounded-xl lg:hidden text-gray-400"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 space-y-2 mt-4 overflow-y-auto custom-scrollbar">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                end={item.path === '/admin'}
                onClick={() => setIsSidebarOpen(false)}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-4 px-5 py-4 rounded-[1.25rem] transition-all group relative",
                    isActive 
                      ? "bg-blue-600 text-white shadow-xl shadow-blue-600/20" 
                      : "text-gray-400 hover:bg-white/5 hover:text-white"
                  )
                }
              >
                <item.icon className="w-6 h-6 flex-shrink-0" />
                <span className={cn("font-bold uppercase tracking-widest text-[10px] transition-all whitespace-nowrap", !isSidebarOpen && "lg:hidden xl:block")}>
                  {item.label}
                </span>
                {!isSidebarOpen && (
                   <div className="absolute left-full ml-6 px-3 py-2 bg-gray-800 text-white text-[10px] font-bold uppercase tracking-widest rounded-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none hidden lg:block xl:hidden z-[100] shadow-2xl border border-white/5 whitespace-nowrap">
                    {item.label}
                  </div>
                )}
              </NavLink>
            ))}
          </nav>

          {/* Footer */}
          <div className="p-6 border-t border-gray-800/50 space-y-4">
            <div className={cn("flex items-center gap-3 p-4 rounded-2xl bg-gray-950 border border-gray-800 transition-all", !isSidebarOpen && "lg:hidden xl:flex")}>
              <div className="w-10 h-10 rounded-full bg-blue-600/20 flex items-center justify-center border border-blue-500/20">
                <ShieldCheck className="w-5 h-5 text-blue-500" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-black truncate">{profile?.displayName?.toUpperCase()}</p>
                <p className="text-[8px] text-gray-500 font-bold uppercase tracking-tighter">{profile?.role?.replace('_', ' ')}</p>
              </div>
            </div>
            <button
              onClick={() => {
                signOut();
                navigate('/auth');
              }}
              className="w-full flex items-center gap-4 px-5 py-4 text-red-500 hover:bg-red-500/10 rounded-2xl transition-all font-black text-[10px] uppercase tracking-widest group"
            >
              <LogOut className="w-6 h-6 flex-shrink-0 group-hover:-translate-x-1 transition-transform" />
              <span className={cn(!isSidebarOpen && "lg:hidden xl:block")}>Logout</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
        {/* Header */}
        <header className="h-20 bg-gray-950/50 backdrop-blur-2xl border-b border-gray-800/50 flex items-center justify-between px-6 md:px-10 sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-3 bg-gray-900 border border-gray-800 hover:border-gray-700 rounded-2xl transition-colors"
            >
              <Menu className="w-6 h-6 text-white" />
            </button>
            <div className="hidden md:block">
              <h3 className="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em] mb-0.5">Control Center</h3>
              <h2 className="text-xl font-black text-white italic tracking-tighter">STATION</h2>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex bg-gray-951 border border-gray-800/50 px-4 py-2 rounded-2xl items-center gap-3">
              <div className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.5)]"></div>
              <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">System Operational</span>
            </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <main className="flex-1 overflow-y-auto p-6 md:p-10 bg-[#030712] custom-scrollbar">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
