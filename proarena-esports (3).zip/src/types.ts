export type UserRole = 'user' | 'moderator' | 'support' | 'admin' | 'super_admin';

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  gameId?: string;
  balance: {
    deposit: number;
    winning: number;
  };
  role: UserRole;
  proId?: string;
  isBlocked?: boolean;
  paymentMethods?: {
    upi?: string;
    bank?: {
      accountHolder: string;
      accountNumber: string;
      ifsc: string;
    };
  };
  createdAt: string;
}

export interface AppSettings {
  isMaintenance: boolean;
  maintenanceMessage?: string;
  upiId?: string;
  qrCodeUrl?: string;
  version: string;
}

export interface Tournament {
  id: string;
  title: string;
  game: string;
  gameMode?: string;
  team1Name?: string;
  team2Name?: string;
  player1Name?: string;
  player2Name?: string;
  map?: string;
  version?: string;
  entryFee: number;
  prizePool: number;
  adminProfit?: number;
  perKill: number;
  matchTime: string;
  playersCount: number;
  maxPlayers: number;
  status: 'upcoming' | 'ongoing' | 'completed' | 'cancelled';
  roomId?: string;
  roomPassword?: string;
  type: 'free' | 'paid';
  thumbnail?: string;
  winnerName?: string;
  winnerProId?: string;
  winnerKills?: number;
  winnerPrize?: number;
  createdAt: string;
}

export interface Transaction {
  id: string;
  userId: string;
  playerId?: string;
  type: 'deposit' | 'entry_fee' | 'winning' | 'withdrawal';
  amount: number;
  balanceType: 'deposit' | 'winning';
  status: 'success' | 'pending' | 'failed';
  description: string;
  utr?: string;
  paymentMethod?: 'UPI' | 'GPay' | 'PhonePe' | 'Bank';
  paymentDetails?: string;
  createdAt: string;
}

export interface Registration {
  id: string;
  tournamentId: string;
  userId: string;
  teamName?: string;
  status: 'registered' | 'cancelled';
  joinedAt: string;
}
