import React from 'react';
import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { Wallet, User, Swords, Home as HomeIcon, ShieldCheck } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';

export default function Layout() {
  const location = useLocation();
  const { user, profile } = useAuth();

  const isSystemAdmin = user?.email === 'sumitdhakad4424@gmail.com';
  const isAdmin = isSystemAdmin || (profile && ['moderator', 'support', 'admin', 'super_admin'].includes(profile.role));

  const navItems = [
    { path: '/', icon: HomeIcon, label: 'Home' },
    { path: '/matches', icon: Swords, label: 'My Matches' },
    { path: '/wallet', icon: Wallet, label: 'Wallet' },
    { path: '/profile', icon: User, label: 'Profile' },
  ];

  if (isAdmin) {
    navItems.push({ path: '/admin', icon: ShieldCheck, label: 'Admin Panel' });
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white pb-20 overflow-x-hidden">
      {/* Main Content */}
      <main className="max-w-md mx-auto w-full px-4 pt-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-gray-900/80 backdrop-blur-lg border-t border-gray-800 px-6 py-3 z-50">
        <div className="flex justify-between items-center max-w-md mx-auto">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  "flex flex-col items-center gap-1 transition-colors relative",
                  isActive ? "text-blue-500" : "text-gray-400 hover:text-gray-200"
                )
              }
            >
              <item.icon className="w-6 h-6" />
              <span className="text-[10px] font-medium uppercase tracking-wider">{item.label}</span>
              {location.pathname === item.path && (
                <motion.div
                  layoutId="nav-glow"
                  className="absolute -top-3 w-8 h-1 bg-blue-500 rounded-full blur-[2px]"
                />
              )}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}
