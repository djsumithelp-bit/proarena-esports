import React from 'react';
import { motion } from 'motion/react';
import { Hammer, ShieldAlert, Clock, RefreshCcw } from 'lucide-react';

export default function MaintenanceScreen() {
  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md text-center space-y-8">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="relative inline-block"
        >
          <div className="w-32 h-32 rounded-[2.5rem] bg-yellow-600/10 border border-yellow-500/20 flex items-center justify-center mx-auto shadow-2xl shadow-yellow-600/5">
            <Hammer className="w-16 h-16 text-yellow-500 animate-bounce" />
          </div>
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            className="absolute -top-4 -right-4 w-12 h-12 rounded-2xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center"
          >
            <RefreshCcw className="w-6 h-6 text-blue-500" />
          </motion.div>
        </motion.div>

        <div className="space-y-4">
          <motion.h1 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-4xl font-black text-white italic tracking-tighter uppercase"
          >
            Under Maintenance
          </motion.h1>
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-gray-400 font-bold uppercase tracking-widest text-xs leading-relaxed"
          >
            We'll be back soon! Our app is undergoing scheduled maintenance to bring you a better experience. Sorry for the inconvenience.
          </motion.p>
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="bg-gray-900 border border-gray-800 rounded-3xl p-6 flex items-center gap-4 text-left"
        >
          <div className="w-12 h-12 rounded-2xl bg-yellow-500/10 flex items-center justify-center">
            <Clock className="w-6 h-6 text-yellow-500" />
          </div>
          <div>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest leading-none mb-1">Estimated Time</p>
            <p className="text-sm font-black text-white italic tracking-tight">Approximately 2 Hours</p>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="flex items-center justify-center gap-2 text-gray-600"
        >
          <ShieldAlert className="w-4 h-4" />
          <span className="text-[10px] font-bold uppercase tracking-widest">Admin Access Restricted</span>
        </motion.div>
      </div>
    </div>
  );
}
