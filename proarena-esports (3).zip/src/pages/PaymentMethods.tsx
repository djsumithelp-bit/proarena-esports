import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { db } from '../lib/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { ArrowLeft, CreditCard, Landmark, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

export default function PaymentMethods() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'upi' | 'bank'>('upi');
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const [upiId, setUpiId] = useState(profile?.paymentMethods?.upi || '');
  const [bankDetails, setBankDetails] = useState({
    accountHolder: profile?.paymentMethods?.bank?.accountHolder || '',
    accountNumber: profile?.paymentMethods?.bank?.accountNumber || '',
    ifsc: profile?.paymentMethods?.bank?.ifsc || '',
  });

  const handleSaveUpi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !upiId) return;
    setLoading(true);

    try {
      await updateDoc(doc(db, 'users', user.uid), {
        'paymentMethods.upi': upiId
      });
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      alert('Failed to save UPI ID');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveBank = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !bankDetails.accountHolder || !bankDetails.accountNumber || !bankDetails.ifsc) return;
    setLoading(true);

    try {
      await updateDoc(doc(db, 'users', user.uid), {
        'paymentMethods.bank': bankDetails
      });
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      alert('Failed to save Bank details');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pb-24 pt-8">
      <div className="flex items-center gap-4 mb-8 px-6">
        <button 
          onClick={() => navigate(-1)}
          className="p-3 bg-gray-900 border border-gray-800 rounded-2xl hover:bg-gray-800 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-gray-400" />
        </button>
        <div>
          <h1 className="text-2xl font-black text-white italic tracking-tighter uppercase">Payment Methods</h1>
          <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest leading-none">Setup your withdrawal accounts</p>
        </div>
      </div>

      <AnimatePresence>
        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mx-6 mb-6 p-4 bg-green-600/10 border border-green-500/20 rounded-2xl flex items-center gap-3"
          >
            <CheckCircle2 className="w-5 h-5 text-green-500" />
            <span className="text-xs font-bold text-green-500 uppercase tracking-widest">Details Saved Successfully!</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="px-6 space-y-6">
        {/* Tabs */}
        <div className="flex bg-gray-900/50 p-1 rounded-2xl border border-gray-800/50">
          <button
            onClick={() => setActiveTab('upi')}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all",
              activeTab === 'upi' ? "bg-blue-600 text-white shadow-lg" : "text-gray-500 hover:text-gray-300"
            )}
          >
            <CreditCard className="w-4 h-4" />
            UPI
          </button>
          <button
            onClick={() => setActiveTab('bank')}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all",
              activeTab === 'bank' ? "bg-blue-600 text-white shadow-lg" : "text-gray-500 hover:text-gray-300"
            )}
          >
            <Landmark className="w-4 h-4" />
            Bank Transfer
          </button>
        </div>

        {activeTab === 'upi' ? (
          <motion.form 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            onSubmit={handleSaveUpi} 
            className="space-y-6"
          >
            <div className="bg-gray-900 rounded-[2rem] border border-gray-800 p-6 space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">UPI ID</label>
                <div className="relative">
                  <input
                    required
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="example@upi"
                    className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 pl-12 pr-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all font-bold"
                  />
                  <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-600" />
                </div>
                <p className="text-[8px] text-gray-600 font-bold uppercase tracking-widest ml-1 italic">We support all major apps like GPay, PhonePe, Paytm</p>
              </div>

              <button
                disabled={loading}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-2xl shadow-xl shadow-blue-600/20 transition-all uppercase tracking-[0.2em] italic flex items-center justify-center gap-2"
              >
                {loading ? "SAVING..." : "SAVE UPI DETAILS"}
              </button>
            </div>
          </motion.form>
        ) : (
          <motion.form 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            onSubmit={handleSaveBank} 
            className="space-y-6"
          >
            <div className="bg-gray-900 rounded-[2.5rem] border border-gray-800 p-8 space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Account Holder Name</label>
                <input
                  required
                  type="text"
                  value={bankDetails.accountHolder}
                  onChange={(e) => setBankDetails({ ...bankDetails, accountHolder: e.target.value })}
                  placeholder="EXACT NAME AS PER BANK"
                  className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all font-bold uppercase"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Account Number</label>
                <input
                  required
                  type="text"
                  value={bankDetails.accountNumber}
                  onChange={(e) => setBankDetails({ ...bankDetails, accountNumber: e.target.value })}
                  placeholder="000000000000"
                  className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all font-mono"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">IFSC Code</label>
                <input
                  required
                  type="text"
                  value={bankDetails.ifsc}
                  onChange={(e) => setBankDetails({ ...bankDetails, ifsc: e.target.value.toUpperCase() })}
                  placeholder="SBIN000XXXX"
                  className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all font-mono uppercase"
                />
              </div>

              <button
                disabled={loading}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-2xl shadow-xl shadow-blue-600/20 transition-all uppercase tracking-[0.2em] italic flex items-center justify-center gap-2"
              >
                {loading ? "SAVING..." : "SAVE BANK DETAILS"}
              </button>
            </div>
          </motion.form>
        )}

        <div className="bg-blue-600/5 border border-blue-600/10 rounded-2xl p-5 flex items-start gap-4">
          <div className="p-2 bg-blue-600/20 rounded-xl">
            <ShieldCheck className="w-5 h-5 text-blue-500" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest mb-1 italic">Auto-Verification Protocol</p>
            <p className="text-[9px] text-gray-500 leading-relaxed font-black uppercase tracking-tight">Your details are stored in an encrypted vault. Only verified admins can view them for processing your withdrawals securely.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
