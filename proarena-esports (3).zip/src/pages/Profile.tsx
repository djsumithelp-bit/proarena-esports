import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { User, LogOut, Edit3, Shield, Gamepad2, CreditCard, Share2, Trophy, ChevronRight } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';

export default function Profile() {
  const { profile, user, signOut } = useAuth();
  const navigate = useNavigate();
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [gameId, setGameId] = useState(profile?.gameId || '');
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        displayName,
        gameId
      });
      setEditing(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  if (!profile) return null;

  return (
    <div className="space-y-8 pb-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white tracking-tight">Account</h1>
        <button onClick={() => setEditing(!editing)} className="p-2 rounded-xl bg-gray-900 border border-gray-800 text-gray-400">
          <Edit3 className="w-5 h-5" />
        </button>
      </div>

      {/* Profile Info */}
      <div className="flex flex-col items-center space-y-4">
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-600 to-indigo-800 p-1">
            <div className="w-full h-full rounded-full bg-gray-950 flex items-center justify-center p-4">
              <User className="w-full h-full text-blue-500" />
            </div>
          </div>
          <div className="absolute -bottom-1 -right-1 bg-green-500 w-6 h-6 rounded-full border-4 border-gray-950"></div>
        </div>
        <div className="text-center">
          <h2 className="text-xl font-bold text-white tracking-tight">{profile.displayName}</h2>
          <div className="flex flex-col items-center gap-1 mt-1">
            <p className="text-gray-500 text-sm">{profile.email}</p>
            <div className="bg-blue-600/10 border border-blue-500/20 px-3 py-1 rounded-lg mt-1">
              <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest leading-none">Player ID: {profile.proId || '000000'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-900 border border-gray-800 rounded-3xl p-5 space-y-2">
          <Trophy className="w-6 h-6 text-yellow-500" />
          <p className="text-2xl font-black text-white italic">0</p>
          <p className="text-[10px] uppercase font-bold text-gray-500 tracking-widest">Wins</p>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-3xl p-5 space-y-2">
          <Gamepad2 className="w-6 h-6 text-blue-500" />
          <p className="text-2xl font-black text-white italic">0</p>
          <p className="text-[10px] uppercase font-bold text-gray-500 tracking-widest">Played</p>
        </div>
      </div>

      {/* Settings Form */}
      {editing ? (
        <motion.form 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleSave} 
          className="bg-gray-900 rounded-3xl border border-gray-800 p-6 space-y-6 shadow-xl"
        >
          <h3 className="font-bold text-gray-300 uppercase text-xs tracking-widest">Edit Profile</h3>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Username</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                placeholder="Enter Username"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">In-Game ID (e.g. BGMI ID)</label>
              <input
                type="text"
                value={gameId}
                onChange={(e) => setGameId(e.target.value)}
                className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                placeholder="Game ID"
              />
            </div>
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="flex-1 bg-gray-800 text-white font-bold py-4 rounded-2xl hover:bg-gray-700 transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="flex-1 bg-blue-600 text-white font-bold py-4 rounded-2xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/20 disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        </motion.form>
      ) : (
        <div className="space-y-3">
          {[
            { 
              icon: Shield, 
              label: 'Security & Privacy', 
              color: 'text-purple-500',
              description: 'Manage your connected accounts and security settings.',
              onClick: () => alert('Security & Privacy: Your account is secured by Google Authentication. Personal data is encrypted and handled according to our privacy policy.')
            },
            { 
              icon: CreditCard, 
              label: 'Payment Methods', 
              color: 'text-green-500',
              description: 'Manage your withdrawal and deposit methods.',
              onClick: () => navigate('/payment-methods')
            },
            { 
              icon: Share2, 
              label: 'Refer and Earn', 
              color: 'text-blue-500',
              description: 'Invite friends and earn rewards for their participation.',
              onClick: () => {
                const code = 'PRO' + user.uid.substring(0,6).toUpperCase();
                navigator.clipboard.writeText(code);
                alert(`Referral Code: ${code}\nCode copied to clipboard! Share this with your friends to earn rewards.`);
              }
            },
          ].map((item, i) => (
            <button 
              key={i} 
              onClick={item.onClick}
              className="w-full flex items-center justify-between p-6 bg-gray-900 border border-gray-800 rounded-3xl group cursor-pointer hover:border-blue-500/50 hover:bg-gray-800/50 transition-all text-left"
            >
              <div className="flex items-center gap-4">
                <div className={cn("w-12 h-12 rounded-2xl bg-gray-950 flex items-center justify-center p-3 border border-gray-800 transition-colors group-hover:border-blue-500/30", item.color)}>
                  <item.icon className="w-full h-full" />
                </div>
                <div>
                  <span className="font-black text-white uppercase italic tracking-tight text-sm">{item.label}</span>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-0.5">{item.description}</p>
                </div>
              </div>
              <div className="w-8 h-8 rounded-xl bg-gray-950 border border-gray-800 flex items-center justify-center p-1 group-hover:bg-blue-600 group-hover:border-blue-500 transition-all">
                <ChevronRight className="w-4 h-4 text-white" />
              </div>
            </button>
          ))}

          {user.email === 'sumitdhakad4424@gmail.com' && (
            <button
              onClick={() => window.location.href = '/admin'}
              className="w-full mt-4 flex items-center justify-center gap-2 p-4 bg-blue-600/10 border border-blue-600/20 rounded-2xl text-blue-500 font-bold hover:bg-blue-600/20 transition-all"
            >
              <Shield className="w-5 h-5" />
              Open Admin Panel
            </button>
          )}

          <button
            onClick={signOut}
            className="w-full mt-4 flex items-center justify-center gap-2 p-4 bg-red-600/10 border border-red-600/20 rounded-2xl text-red-500 font-bold hover:bg-red-600/20 transition-all"
          >
            <LogOut className="w-5 h-5" />
            Sign Out
          </button>
        </div>
      )}

      <p className="text-center text-[10px] text-gray-600 font-bold uppercase tracking-[0.3em] pb-4">
        PROARENA VERSION 1.0.0
      </p>
    </div>
  );
}
