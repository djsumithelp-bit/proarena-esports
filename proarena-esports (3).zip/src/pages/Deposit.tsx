import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { collection, addDoc, doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { ArrowLeft, Landmark, QrCode, Copy, CheckCircle2, Loader2, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatCurrency } from '../lib/utils';
import { AppSettings } from '../types';

export default function Deposit() {
  const { profile, user } = useAuth();
  const navigate = useNavigate();
  const [amount, setAmount] = useState('');
  const [utr, setUtr] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [paySettings, setPaySettings] = useState<{ upiId: string, qrCodeUrl: string } | null>(null);
  const [fetching, setFetching] = useState(true);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const snap = await getDoc(doc(db, 'settings', 'app'));
        if (snap.exists()) {
          const data = snap.data() as AppSettings;
          setPaySettings({
            upiId: data.upiId || '8889040032@ybl',
            qrCodeUrl: data.qrCodeUrl || ''
          });
        }
      } catch (err) {
        console.error("Error fetching payment settings:", err);
      } finally {
        setFetching(false);
      }
    };
    fetchSettings();
  }, []);

  const copyToClipboard = () => {
    if (!paySettings) return;
    navigator.clipboard.writeText(paySettings.upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;
    if (!amount || isNaN(Number(amount)) || Number(amount) < 1) {
      alert("Please enter a valid amount (Min $1)");
      return;
    }
    if (!utr || utr.length < 10) {
      alert("Please enter a valid 12-digit UTR / Transaction ID");
      return;
    }

    setSubmitting(true);
    try {
      await addDoc(collection(db, 'transactions'), {
        userId: user.uid,
        playerId: profile.proId,
        amount: Number(amount),
        utr: utr.trim(),
        type: 'deposit',
        balanceType: 'deposit',
        status: 'pending',
        description: 'Manual UPI Deposit',
        createdAt: new Date().toISOString()
      });

      alert("Deposit request submitted successfully! Your balance will be updated once the admin verifies the UTR.");
      navigate('/wallet');
    } catch (err) {
      console.error(err);
      alert("Failed to submit deposit request. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (!profile) return null;

  return (
    <div className="space-y-6 pb-10">
      <div className="flex items-center gap-4">
        <button 
          onClick={() => navigate(-1)}
          className="p-3 bg-gray-900 border border-gray-800 rounded-2xl text-gray-400 hover:text-white transition-all"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div>
          <h1 className="text-2xl font-black text-white italic uppercase tracking-tighter">Add Money</h1>
          <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest">Manual UPI Deposit</p>
        </div>
      </div>

      {fetching ? (
        <div className="flex flex-col items-center justify-center py-20 bg-gray-900 border border-gray-800 rounded-[2.5rem]">
          <Loader2 className="w-10 h-10 text-blue-500 animate-spin mb-4" />
          <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest italic">Loading Payment Gateway...</p>
        </div>
      ) : (
        <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] overflow-hidden shadow-2xl">
          <div className="p-8 space-y-8">
            {/* Step 1: Payment Details */}
            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-black text-xs">1</div>
                <h3 className="font-black text-white uppercase text-xs tracking-widest">Pay via UPI / QR Code</h3>
              </div>

              <div className="flex flex-col items-center gap-6 p-6 bg-gray-950/50 rounded-3xl border border-gray-800/50 border-dashed">
                <div className="bg-white p-4 rounded-3xl relative group">
                  {paySettings?.qrCodeUrl ? (
                    <img 
                      src={paySettings.qrCodeUrl} 
                      alt="Payment QR" 
                      className="w-40 h-40 object-contain rounded-2xl"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-40 h-40 bg-gray-50 flex items-center justify-center border-2 border-gray-100 rounded-2xl">
                      <QrCode className="w-32 h-32 text-gray-900" />
                    </div>
                  )}
                  <div className="absolute inset-0 flex items-center justify-center bg-white/90 opacity-0 group-hover:opacity-100 transition-opacity rounded-3xl">
                    <p className="text-gray-900 text-[8px] font-black uppercase tracking-widest text-center px-4">Scan using GPay, PhonePe, or Paytm</p>
                  </div>
                </div>

                <div className="w-full space-y-3">
                  <p className="text-center text-[10px] font-black text-gray-500 uppercase tracking-widest leading-none">UPI ID</p>
                  <div className="flex items-center gap-2 bg-gray-900 border border-gray-800 rounded-2xl p-4">
                    <Landmark className="w-5 h-5 text-blue-500" />
                    <span className="flex-1 text-white font-black italic text-sm tracking-tight">{paySettings?.upiId}</span>
                    <button 
                      onClick={copyToClipboard}
                      className="p-2 bg-blue-600/10 text-blue-500 rounded-xl hover:bg-blue-600/20 transition-all active:scale-95"
                    >
                      {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="h-px bg-gray-800 border-dashed border-t w-full" />

            {/* Step 2: Submission Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-black text-xs">2</div>
                <h3 className="font-black text-white uppercase text-xs tracking-widest">Submit Transaction Details</h3>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Amount to Add ($)</label>
                  <div className="relative">
                    <span className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-500 font-black italic">$</span>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="Min $1"
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-5 pl-10 pr-6 text-white text-lg font-bold focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">UTR / Transaction ID (12 Digits)</label>
                  <input
                    type="text"
                    value={utr}
                    onChange={(e) => setUtr(e.target.value)}
                    placeholder="Enter 12-digit UTR number"
                    className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-5 px-6 text-white text-lg font-mono focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                    required
                  />
                </div>

                <div className="bg-blue-600/5 border border-blue-500/20 p-4 rounded-2xl flex gap-3">
                  <Info className="w-5 h-5 text-blue-500 flex-shrink-0" />
                  <p className="text-[9px] text-blue-300 font-medium leading-relaxed italic uppercase tracking-widest">
                    Important: Ensure the UTR number is correct. Wrong UTR will lead to rejection. Approval usually takes 5-15 minutes.
                  </p>
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting || !amount || !utr}
                className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl hover:bg-blue-700 transition-all shadow-xl shadow-blue-600/20 flex items-center justify-center gap-2 disabled:opacity-50 uppercase tracking-widest"
              >
                {submitting ? <Loader2 className="w-6 h-6 animate-spin" /> : "Submit Request"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
