import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, onSnapshot, writeBatch, collection, query, where, getDocs, updateDoc, increment, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { Tournament, Registration } from '../types';
import { Trophy, Users, Clock, ArrowLeft, Gamepad2, ShieldCheck, Share2, Lock, Key, X } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { format, isAfter, subMinutes } from 'date-fns';

export default function TournamentDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { profile, user } = useAuth();
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [isJoined, setIsJoined] = useState(false);
  const [joining, setJoining] = useState(false);
  const [showJoinForm, setShowJoinForm] = useState(false);
  const [playerData, setPlayerData] = useState({
    ign: '',
    uid: '',
    level: ''
  });
  const [error, setError] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isMaintenance, setIsMaintenance] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'app'), (snap) => {
      if (snap.exists()) {
        setIsMaintenance(snap.data().isMaintenance);
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 30000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!id) return;
    const unsubscribe = onSnapshot(doc(db, 'tournaments', id), (doc) => {
      if (doc.exists()) {
        setTournament({ id: doc.id, ...doc.data() } as Tournament);
      }
    });

    const checkJoined = async () => {
      if (!user || !id) return;
      const q = query(
        collection(db, 'tournaments', id, 'registrations'),
        where('userId', '==', user.uid)
      );
      const snapshot = await getDocs(q);
      setIsJoined(!snapshot.empty);
    };

    checkJoined();
    return () => unsubscribe();
  }, [id, user]);

  const handleJoin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!tournament || !profile || !user || !id) return;
    if (isJoined) return;
    
    if (isMaintenance) {
      setError('Platform is under maintenance. Joining is disabled.');
      return;
    }

    // Validate inputs
    if (!playerData.ign || !playerData.uid || !playerData.level) {
      setError('Please fill in all player details.');
      return;
    }

    // Check balance
    const totalBalance = profile.balance.deposit + profile.balance.winning;
    if (totalBalance < tournament.entryFee) {
      setError('Insufficient balance. Please add money to your wallet.');
      setTimeout(() => navigate('/wallet'), 2000);
      return;
    }

    if (tournament.playersCount >= tournament.maxPlayers) {
      setError('Tournament is full!');
      return;
    }

    setJoining(true);
    setError('');

    try {
      const batch = writeBatch(db);

      // 1. Create registration with player details
      const registrationRef = doc(collection(db, 'tournaments', id, 'registrations'));
      batch.set(registrationRef, {
        tournamentId: id,
        userId: user.uid,
        ign: playerData.ign.toUpperCase(),
        uid: playerData.uid,
        level: playerData.level,
        status: 'registered',
        joinedAt: new Date().toISOString()
      });

      // 2. Update tournament player count
      const tournamentRef = doc(db, 'tournaments', id);
      batch.update(tournamentRef, {
        playersCount: increment(1)
      });

      // 3. Deduct balance (Deduct from deposit first, then winnings)
      const userRef = doc(db, 'users', user.uid);
      let newDeposit = profile.balance.deposit;
      let newWinning = profile.balance.winning;
      let remainingFee = tournament.entryFee;

      if (newDeposit >= remainingFee) {
        newDeposit -= remainingFee;
        remainingFee = 0;
      } else {
        remainingFee -= newDeposit;
        newDeposit = 0;
        newWinning -= remainingFee;
      }

      batch.update(userRef, {
        'balance.deposit': newDeposit,
        'balance.winning': newWinning
      });

      // 4. Create Transaction record
      const transRef = doc(collection(db, 'transactions'));
      batch.set(transRef, {
        userId: user.uid,
        type: 'entry_fee',
        amount: tournament.entryFee,
        balanceType: 'mixed',
        status: 'success',
        description: `Joined ${tournament.title}`,
        createdAt: new Date().toISOString()
      });

      await batch.commit();
      setIsJoined(true);
      setShowJoinForm(false);
      alert('Joined Successfully! Your spot is confirmed.');
    } catch (err: any) {
      setError('Failed to join tournament: ' + err.message);
    } finally {
      setJoining(false);
    }
  };

  if (!tournament) return (
    <div className="min-h-screen flex items-center justify-center">
      <Clock className="animate-spin" />
    </div>
  );

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="p-2 rounded-xl bg-gray-900 border border-gray-800 text-gray-400">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h2 className="font-bold text-lg">Tournament Details</h2>
        <button className="p-2 rounded-xl bg-gray-900 border border-gray-800 text-gray-400">
          <Share2 className="w-6 h-6" />
        </button>
      </div>

      {/* Info Card */}
      <div className="bg-gray-900 rounded-3xl border border-gray-800 overflow-hidden shadow-2xl">
        {tournament.thumbnail && (
          <div className="h-48 w-full overflow-hidden border-b border-gray-800 relative">
             <img src={tournament.thumbnail} alt={tournament.title} className="w-full h-full object-cover" />
             <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
          </div>
        )}
        <div className="p-6 space-y-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-blue-600/20 flex items-center justify-center flex-shrink-0">
               <Trophy className="w-8 h-8 text-blue-500" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white uppercase tracking-tight italic">{tournament.title}</h1>
              <p className="text-gray-400 text-sm font-medium">{tournament.game}</p>
            </div>
          </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-950 p-4 rounded-2xl border border-gray-800">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Prize Pool</p>
            <p className="text-lg font-black text-yellow-500">{formatCurrency(tournament.prizePool)}</p>
          </div>
          <div className="bg-gray-950 p-4 rounded-2xl border border-gray-800">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Entry Fee</p>
            <p className="text-lg font-black text-blue-500">
              {tournament.entryFee === 0 ? 'FREE' : formatCurrency(tournament.entryFee)}
            </p>
          </div>
          <div className="bg-gray-950 p-4 rounded-2xl border border-gray-800">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Map</p>
            <p className="text-base font-black text-white uppercase">{tournament.map || 'Bermuda'}</p>
          </div>
          <div className="bg-gray-950 p-4 rounded-2xl border border-gray-800">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Mode & Version</p>
            <p className="text-[10px] font-black text-white uppercase tracking-tight">
              {tournament.gameMode || 'BR'} | {tournament.version || 'Mobile'}
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-gray-400">
              <Users className="w-4 h-4" />
              <span>Participants</span>
            </div>
            <span className="font-bold text-white">{tournament.playersCount} / {tournament.maxPlayers}</span>
          </div>
          <div className="w-full bg-gray-800 h-2 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${(tournament.playersCount / tournament.maxPlayers) * 100}%` }}
              className="bg-blue-600 h-full"
            />
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-gray-400">
              <Clock className="w-4 h-4" />
              <span>Match Time</span>
            </div>
            <span className="font-bold text-white">{format(new Date(tournament.matchTime), 'PPP p')}</span>
          </div>
        </div>
      </div>
    </div>

      {/* Credentials for Joined User */}
      {isJoined && (
        <div className="px-2">
          {(() => {
            const matchTime = new Date(tournament.matchTime);
            const isRevealTime = isAfter(currentTime, subMinutes(matchTime, 15));
            const hasCredentials = tournament.roomId && tournament.roomPassword;

            if (isRevealTime && hasCredentials) {
              return (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-green-600/10 border border-green-500/20 rounded-[2rem] p-6 space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <p className="text-[10px] font-black text-green-500 uppercase tracking-[0.2em] italic">Room Credentials Live</p>
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">Room ID</p>
                      <p className="text-white font-black tracking-widest select-all bg-gray-950 px-3 py-2 rounded-xl border border-gray-800/50">{tournament.roomId}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">Password</p>
                      <p className="text-white font-black tracking-widest select-all bg-gray-950 px-3 py-2 rounded-xl border border-gray-800/50">{tournament.roomPassword}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(`ID: ${tournament.roomId} | PASS: ${tournament.roomPassword}`);
                      alert('Credentials copied to clipboard!');
                    }}
                    className="w-full py-3 bg-green-600 text-white font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-green-700 transition-all flex items-center justify-center gap-2"
                  >
                    <Key className="w-4 h-4" />
                    Copy Credentials
                  </button>
                </motion.div>
              );
            }

            return (
              <div className="bg-blue-600/10 border border-blue-500/20 rounded-[2rem] p-6 flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center flex-shrink-0">
                  <Lock className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold text-blue-400 uppercase tracking-widest leading-none mb-1">Room Credentials</p>
                  <p className="text-[10px] text-gray-500">
                    {isRevealTime ? "Admin hasn't updated ID/Pass yet." : "Credentials will be visible 15 minutes before the match starts."}
                  </p>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* Rules Section */}
      <div className="space-y-4 px-2">
        <h3 className="font-bold text-gray-300 uppercase text-xs tracking-widest">Match Rules</h3>
        <div className="space-y-3">
          {[
            'No hackers or cheaters allowed.',
            'Team up is strictly prohibited.',
            'Be ready 10 minutes before the match starts.',
            'Prize distribution within 24 hours.'
          ].map((rule, i) => (
            <div key={i} className="flex gap-3 text-sm text-gray-400">
              <div className="mt-1 w-1.5 h-1.5 rounded-full bg-blue-600 flex-shrink-0"></div>
              {rule}
            </div>
          ))}
        </div>
      </div>

      {/* Fixed Join Button */}
      <div className="fixed bottom-24 left-0 right-0 px-6">
        <div className="max-w-md mx-auto">
          {error && <p className="text-red-500 text-xs text-center mb-2 font-bold uppercase tracking-widest">{error}</p>}
          <button
            onClick={() => {
              if (isJoined) return;
              setShowJoinForm(true);
            }}
            disabled={joining || isJoined || tournament.playersCount >= tournament.maxPlayers}
            className={cn(
              "w-full py-4 rounded-2xl font-black shadow-xl transition-all active:scale-[0.98] flex items-center justify-center gap-2 uppercase tracking-[0.2em] italic",
              isJoined 
                ? "bg-green-600/20 text-green-500 border border-green-600/30 cursor-default" 
                : "bg-blue-600 hover:bg-blue-700 text-white shadow-blue-600/20"
            )}
          >
            {isJoined ? (
              <>
                <ShieldCheck className="w-5 h-5 text-green-500" />
                Joined Successfully
              </>
            ) : joining ? (
              <Clock className="animate-spin" />
            ) : tournament.playersCount >= tournament.maxPlayers ? (
              'Tournament Full'
            ) : (
              `Join for ${tournament.entryFee === 0 ? 'FREE' : formatCurrency(tournament.entryFee)}`
            )}
          </button>
        </div>
      </div>

      {/* Join Registration Modal */}
      <AnimatePresence>
        {showJoinForm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowJoinForm(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 w-full max-w-sm relative z-10 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h3 className="text-2xl font-black text-white italic tracking-tighter">CONFIRM JOIN</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{tournament.title}</p>
                </div>
                <button onClick={() => setShowJoinForm(false)} className="p-2 hover:bg-gray-800 rounded-full">
                  <X className="w-6 h-6 text-gray-400" />
                </button>
              </div>

              <form onSubmit={handleJoin} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">In-Game Name (IGN)</label>
                  <input
                    required
                    type="text"
                    value={playerData.ign}
                    onChange={(e) => setPlayerData({ ...playerData, ign: e.target.value })}
                    className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50 uppercase font-bold"
                    placeholder="ENTER YOUR IGN"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Game UID</label>
                    <input
                      required
                      type="number"
                      value={playerData.uid}
                      onChange={(e) => setPlayerData({ ...playerData, uid: e.target.value })}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50 font-mono"
                      placeholder="UID"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Level</label>
                    <input
                      required
                      type="number"
                      value={playerData.level}
                      onChange={(e) => setPlayerData({ ...playerData, level: e.target.value })}
                      className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-4 px-5 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50"
                      placeholder="LEVEL"
                    />
                  </div>
                </div>

                <div className="bg-blue-600/5 border border-blue-600/10 rounded-2xl p-4">
                  <div className="flex justify-between items-center text-xs font-bold uppercase tracking-widest">
                    <span className="text-gray-500">Entry Fee</span>
                    <span className="text-blue-500">{formatCurrency(tournament.entryFee)}</span>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={joining}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-600/20 transition-all uppercase tracking-[0.2em] flex items-center justify-center gap-2"
                >
                  {joining ? <Clock className="w-5 h-5 animate-spin" /> : 'Confirm Payment'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
