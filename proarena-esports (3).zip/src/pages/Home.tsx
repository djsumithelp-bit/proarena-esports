import React, { useEffect, useState } from 'react';
import { collection, query, onSnapshot, orderBy, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Tournament } from '../types';
import { Trophy, Users, Clock, ArrowRight, Gamepad2, Search, Bell, Target, Crosshair, Map, Users2 } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { formatCurrency } from '../lib/utils';
import { motion } from 'motion/react';
import { format } from 'date-fns';

export default function Home() {
  const navigate = useNavigate();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'tournaments'), orderBy('matchTime', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Tournament[];
      setTournaments(data);
      setLoading(false);
    }, (error) => {
      console.error("Home matches error:", error);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const filteredTournaments = tournaments.filter(t => 
    (t.status === 'upcoming' || t.status === 'ongoing') &&
    (t.title.toLowerCase().includes(search.toLowerCase()) || 
    t.game.toLowerCase().includes(search.toLowerCase()))
  );

  const gameModes = [
    {
      id: 'cs',
      title: 'Clash Squad',
      desc: 'Intense 4v4 Team Combat',
      icon: Users2,
      color: 'blue',
      path: '/tournaments?type=cs',
      bg: 'bg-blue-600',
      border: 'border-blue-500/30',
      glow: 'shadow-blue-600/20'
    },
    {
      id: 'lw',
      title: 'Lone Wolf',
      desc: 'Tactical 1v1 Sniper Duels',
      icon: Crosshair,
      color: 'red',
      path: '/tournaments?type=lw',
      bg: 'bg-red-600',
      border: 'border-red-500/30',
      glow: 'shadow-red-600/20'
    },
    {
      id: 'br',
      title: 'Battle Royale',
      desc: 'Last Man Standing Wins',
      icon: Map,
      color: 'green',
      path: '/tournaments?type=br',
      bg: 'bg-green-600',
      border: 'border-green-500/30',
      glow: 'shadow-green-600/20'
    }
  ];

  return (
    <div className="space-y-8 pb-10">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tighter uppercase font-display italic">
            Pro<span className="text-blue-500">Arena</span> Esports
          </h1>
          <p className="text-gray-400 text-[10px] font-black uppercase tracking-[0.2em] mt-1">
            Match Center • Win Real Prize
          </p>
        </div>
        <button className="p-3 rounded-2xl bg-gray-900 border border-gray-800 text-gray-400 hover:text-white transition-all relative">
          <Bell className="w-6 h-6" />
          <span className="absolute top-3 right-3 w-2.5 h-2.5 bg-red-500 border-2 border-gray-900 rounded-full"></span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative group">
        <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-600 group-focus-within:text-blue-500 transition-colors" />
        <input
          type="text"
          placeholder="Search tournaments or games..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-gray-900/40 backdrop-blur-xl border border-gray-800 rounded-[2rem] py-5 pl-14 pr-6 text-white text-sm font-bold placeholder:text-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-600/30 transition-all"
        />
      </div>

      {/* Game Modes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {gameModes.map((mode) => (
          <motion.div
            key={mode.id}
            whileHover={{ y: -5, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate(mode.path)}
            className={`relative group h-64 rounded-[2.5rem] overflow-hidden border ${mode.border} ${mode.glow} shadow-xl cursor-pointer transition-all duration-300`}
          >
            {/* Background Aesthetic */}
            <div className={`absolute inset-0 opacity-20 bg-gradient-to-br ${mode.bg} to-black group-hover:opacity-30 transition-opacity`}></div>
            <div className="absolute top-0 right-0 w-40 h-40 blur-[80px] opacity-30 rounded-full bg-white translate-x-12 -translate-y-12"></div>
            
            <div className="relative h-full p-8 flex flex-col justify-between">
              <div className={`w-16 h-16 rounded-2xl ${mode.bg} bg-opacity-20 flex items-center justify-center border border-white/10 shadow-inner group-hover:scale-110 transition-transform duration-500`}>
                <mode.icon className={`w-8 h-8 text-white shadow-sm`} />
              </div>
              
              <div>
                <h3 className="text-2xl font-black text-white italic tracking-tighter uppercase mb-2 group-hover:translate-x-1 transition-transform">{mode.title}</h3>
                <p className="text-[10px] text-gray-300 font-black uppercase tracking-widest mb-6 opacity-70 leading-relaxed">{mode.desc}</p>
                
                <div className={`w-full py-4 ${mode.bg} text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl shadow-xl ring-1 ring-white/20 group-hover:brightness-110 transition-all flex items-center justify-center gap-2`}>
                  Join Now
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Tournaments Section */}
      <div className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <div className="space-y-1 border-l-4 border-blue-500 pl-4">
            <h3 className="font-black text-white italic text-xl uppercase tracking-tighter">Live & Upcoming</h3>
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Global Battle Lobby</p>
          </div>
          <Link to="/tournaments" className="px-4 py-2 bg-gray-900 border border-gray-800 rounded-xl text-blue-500 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-gray-800 transition-all">
            See All <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        {loading ? (
          <div className="grid gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-40 bg-gray-900 rounded-[2rem] animate-pulse border border-gray-800"></div>
            ))}
          </div>
        ) : filteredTournaments.length === 0 ? (
          <div className="text-center py-20 bg-gray-900/40 rounded-[3rem] border border-gray-800 border-dashed">
            <Gamepad2 className="w-16 h-16 text-gray-800 mx-auto mb-4 opacity-50" />
            <p className="text-gray-500 font-black uppercase italic tracking-widest text-xs">No active tournaments found</p>
            <p className="text-gray-600 text-[10px] font-bold uppercase tracking-widest mt-2">Check back later for new events</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {filteredTournaments.map((tournament) => (
              <Link 
                key={tournament.id} 
                to={`/tournaments/${tournament.id}`}
                className="block group"
              >
                <div className="bg-gray-900/60 backdrop-blur-md border border-gray-800 rounded-[2.5rem] p-5 transition-all group-hover:border-blue-500/30 group-hover:bg-gray-900/90 group-hover:shadow-[0_0_40px_rgba(37,99,235,0.05)]">
                  <div className="flex gap-5">
                    <div className="w-24 h-24 rounded-[1.5rem] bg-gray-800 flex-shrink-0 overflow-hidden border border-gray-700 p-0.5 shadow-inner">
                      {tournament.thumbnail ? (
                        <img src={tournament.thumbnail} className="w-full h-full object-cover rounded-[1.25rem]" alt={tournament.title} />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gray-950 rounded-[1.25rem]">
                          <Gamepad2 className="w-10 h-10 text-gray-800" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-black text-white truncate text-xl italic tracking-tighter uppercase group-hover:text-blue-400 transition-colors leading-none">
                            {tournament.title}
                          </h4>
                          {tournament.status === 'ongoing' && (
                            <span className="flex items-center gap-1 bg-red-600/10 border border-red-500/20 text-red-500 text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest animate-pulse">
                              <span className="w-1 h-1 bg-red-500 rounded-full"></span> Live
                            </span>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <div className="flex items-center gap-1.5 bg-yellow-500/10 border border-yellow-500/20 px-2 py-1 rounded-lg">
                            <Trophy className="w-3.5 h-3.5 text-yellow-500" />
                            <span className="text-[10px] font-black text-yellow-400 uppercase tracking-tighter">
                              {formatCurrency(tournament.prizePool)}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 bg-blue-500/10 border border-blue-500/20 px-2 py-1 rounded-lg">
                            <Gamepad2 className="w-3.5 h-3.5 text-blue-500" />
                            <span className="text-[10px] font-black text-blue-400 uppercase tracking-tighter">
                              {tournament.gameMode || 'BR'}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-4 border-t border-gray-800 mt-2">
                        <div className="flex items-center gap-4 text-[10px] font-black text-gray-500 uppercase tracking-widest">
                          <div className="flex items-center gap-2 bg-gray-950/50 px-3 py-1.5 rounded-xl border border-gray-800/50">
                            <Users className="w-3.5 h-3.5 text-blue-500" />
                            <span className="text-gray-300">{tournament.playersCount}/{tournament.maxPlayers}</span>
                          </div>
                          <div className="flex items-center gap-2 bg-gray-950/50 px-3 py-1.5 rounded-xl border border-gray-800/50">
                            <Clock className="w-3.5 h-3.5 text-green-500" />
                            <span className="text-gray-300">{format(new Date(tournament.matchTime), 'p')}</span>
                          </div>
                        </div>
                        <div className="text-sm font-black text-white bg-blue-600 px-5 py-2 rounded-2xl shadow-lg shadow-blue-600/30 italic tracking-tighter uppercase group-hover:scale-105 transition-transform">
                          {tournament.entryFee === 0 ? 'FREE JOIN' : `${formatCurrency(tournament.entryFee)}`}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
