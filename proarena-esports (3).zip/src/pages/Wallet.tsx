import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { collection, query, where, orderBy, onSnapshot, doc, updateDoc, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Transaction } from '../types';
import { Wallet as WalletIcon, Plus, History, ArrowUpRight, ArrowDownLeft, Loader2, Sparkles, Settings, ChevronRight, CreditCard, Landmark, CheckCircle2 } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { format } from 'date-fns';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';

export default function Wallet() {
  const { profile, user } = useAuth();
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw'>('deposit');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawing, setWithdrawing] = useState(false);
  const [isMaintenance, setIsMaintenance] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'app'), (snap) => {
      if (snap.exists()) {
        setIsMaintenance(snap.data().isMaintenance);
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    const q = query(
      collection(db, 'transactions'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Transaction[];
      setTransactions(data);
      setLoading(false);
    }, (error) => {
      console.error("Transactions snapshot error:", error);
      setLoading(false);
    });
    return () => unsubscribe();
  }, [user?.uid]);

  const handleWithdraw = async () => {
    if (!withdrawAmount || isNaN(Number(withdrawAmount)) || Number(withdrawAmount) < 1 || !user || !profile) {
      alert("Please enter a valid withdrawal amount.");
      return;
    }

    const hasUPI = !!profile.paymentMethods?.upi;
    const hasBank = !!profile.paymentMethods?.bank;

    if (!hasUPI && !hasBank) {
      alert("Please setup a payment method in your Profile first.");
      navigate('/payment-methods');
      return;
    }
    
    const amountNum = Number(withdrawAmount);

    if (amountNum > profile.balance.winning) {
      alert("Insufficient winning balance.");
      return;
    }

    if (isMaintenance) {
      alert("Platform is under maintenance. Withdrawals are temporarily disabled.");
      return;
    }

    setWithdrawing(true);
    try {
      const userRef = doc(db, 'users', user.uid);
      const transactionsRef = collection(db, 'transactions');

      // Deduct from winning balance immediately (escrow)
      await updateDoc(userRef, {
        'balance.winning': profile.balance.winning - amountNum
      });

      const selectedMethod = profile.paymentMethods?.upi ? 'UPI' : 'Bank';
      const selectedDetails = profile.paymentMethods?.upi 
        ? profile.paymentMethods.upi 
        : `${profile.paymentMethods?.bank?.accountHolder} | ${profile.paymentMethods?.bank?.accountNumber} | ${profile.paymentMethods?.bank?.ifsc}`;

      // Create detailed transaction record
      await addDoc(transactionsRef, {
        userId: user.uid,
        amount: amountNum,
        type: 'withdrawal',
        balanceType: 'winning',
        status: 'pending',
        paymentMethod: selectedMethod,
        paymentDetails: selectedDetails,
        description: `Withdrawal to ${selectedMethod}`,
        createdAt: new Date().toISOString()
      });

      setWithdrawAmount('');
      alert(`Withdrawal request for $${amountNum} submitted!`);
    } catch (err) {
      console.error('Withdraw failed:', err);
      alert('Withdrawal request failed.');
    } finally {
      setWithdrawing(false);
    }
  };

  if (!profile) return null;

  return (
    <div className="space-y-8 pb-20">
      <div className="flex justify-between items-center px-1">
        <h1 className="text-3xl font-black text-white italic tracking-tighter uppercase">Wallet</h1>
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-1 flex gap-1">
          <button 
            onClick={() => setActiveTab('deposit')}
            className={cn(
              "px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
              activeTab === 'deposit' ? "bg-white text-gray-950 shadow-lg" : "text-gray-500 hover:text-gray-300"
            )}
          >
            Deposit
          </button>
          <button 
            onClick={() => setActiveTab('withdraw')}
            className={cn(
              "px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
              activeTab === 'withdraw' ? "bg-white text-gray-950 shadow-lg" : "text-gray-500 hover:text-gray-300"
            )}
          >
            Withdraw
          </button>
        </div>
      </div>

      {/* Balance Card */}
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-gray-900 border-2 border-gray-800 rounded-[2.5rem] p-8 relative overflow-hidden group shadow-2xl"
      >
         <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/5 rounded-full -translate-y-32 translate-x-32 blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="space-y-2 text-center md:text-left">
            <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">Available Balance</p>
            <h2 className="text-5xl font-black italic text-white tracking-tighter">
              {formatCurrency(profile.balance.deposit + profile.balance.winning)}
            </h2>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-950/50 border border-gray-800 p-4 rounded-3xl min-w-[140px] text-center">
              <p className="text-[8px] font-black text-blue-500 uppercase tracking-widest mb-1">Deposit</p>
              <p className="text-xl font-black text-white italic">{formatCurrency(profile.balance.deposit)}</p>
            </div>
            <div className="bg-gray-950/50 border border-gray-800 p-4 rounded-3xl min-w-[140px] text-center">
              <p className="text-[8px] font-black text-green-500 uppercase tracking-widest mb-1">Winning</p>
              <p className="text-xl font-black text-white italic">{formatCurrency(profile.balance.winning)}</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Action Content */}
      <div className="max-w-xl mx-auto w-full">
        {activeTab === 'deposit' ? (
          <motion.div 
            key="deposit"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 space-y-6 shadow-xl text-center">
              <div className="w-20 h-20 bg-blue-600/10 rounded-3xl flex items-center justify-center mx-auto border border-blue-500/20 mb-4">
                <Plus className="w-10 h-10 text-blue-500" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter">Add Money</h3>
                <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest max-w-[240px] mx-auto leading-relaxed">
                  Top up your account via UPI, GPay, or PhonePe to join paid matches.
                </p>
              </div>

              <button
                onClick={() => navigate('/deposit')}
                className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl hover:bg-blue-700 transition-all shadow-xl shadow-blue-600/20 flex items-center justify-center gap-2 uppercase tracking-widest"
              >
                Go to Deposit Page
                <ChevronRight className="w-5 h-5" />
              </button>
              
              <div className="flex items-center justify-center gap-4 pt-2 opacity-50 grayscale hover:grayscale-0 transition-all">
                <img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/UPI-Logo-vector.svg" alt="UPI" className="h-4" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/d/d0/Google_Pay_Logo.svg" alt="GPay" className="h-4" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/7/71/PhonePe_Logo.svg" alt="PhonePe" className="h-4" />
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key="withdraw"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-8 space-y-6 shadow-xl">
              <div className="space-y-4">
                <div className="flex items-center justify-between ml-1">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest leading-none">Receiving Method</label>
                  <button 
                    onClick={() => navigate('/payment-methods')}
                    className="text-[10px] font-black text-blue-500 uppercase tracking-widest hover:text-blue-400 transition-colors flex items-center gap-1"
                  >
                    <Settings className="w-3 h-3" />
                    Change
                  </button>
                </div>
                
                {profile.paymentMethods?.upi || profile.paymentMethods?.bank ? (
                  <div className="bg-gray-950 border border-gray-800 rounded-3xl p-5 flex items-center justify-between group transition-all hover:border-gray-700">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-blue-600/10 flex items-center justify-center border border-blue-500/20">
                        {profile.paymentMethods?.upi ? <CreditCard className="w-6 h-6 text-blue-500" /> : <Landmark className="w-6 h-6 text-blue-500" />}
                      </div>
                      <div>
                        <p className="text-sm font-black text-white italic uppercase tracking-tight">
                          {profile.paymentMethods?.upi ? 'UPI Transfer' : 'Bank Transfer'}
                        </p>
                        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest truncate max-w-[180px]">
                          {profile.paymentMethods?.upi ? profile.paymentMethods.upi : profile.paymentMethods?.bank?.accountNumber}
                        </p>
                      </div>
                    </div>
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                  </div>
                ) : (
                  <button 
                    onClick={() => navigate('/payment-methods')}
                    className="w-full bg-gray-950 border-2 border-dashed border-gray-800 rounded-3xl p-6 flex flex-col items-center justify-center gap-2 hover:border-blue-500/50 hover:bg-gray-900 transition-all group"
                  >
                    <Plus className="w-6 h-6 text-gray-600 group-hover:text-blue-500" />
                    <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest group-hover:text-gray-300">Add Payment Method</span>
                  </button>
                )}
              </div>

              <div className="space-y-3">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Withdraw Amount</label>
                <div className="relative">
                  <span className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-500 font-black italic">$</span>
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-5 pl-10 pr-6 text-white text-lg font-bold focus:outline-none focus:ring-2 focus:ring-green-600/50"
                  />
                </div>
                <div className="flex items-center justify-between px-1">
                  <p className="text-[9px] font-black text-gray-600 uppercase tracking-widest">Withdrawal Fee: $2.00</p>
                  <p className="text-[9px] font-black text-green-500 uppercase tracking-widest">
                    Available: {formatCurrency(profile.balance.winning)}
                  </p>
                </div>
              </div>

              <button
                onClick={handleWithdraw}
                disabled={withdrawing || !withdrawAmount || (!profile.paymentMethods?.upi && !profile.paymentMethods?.bank)}
                className="w-full bg-green-600 text-white font-black py-5 rounded-2xl hover:bg-green-700 transition-all shadow-xl flex items-center justify-center gap-2 disabled:opacity-50 uppercase tracking-widest shadow-green-600/20"
              >
                {withdrawing ? <Loader2 className="animate-spin w-6 h-6" /> : 'Confirm Payout Request'}
              </button>
            </div>
          </motion.div>
        )}
      </div>

      {/* Transaction History */}
      <div className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <h3 className="font-black text-white uppercase italic tracking-tighter text-xl">History</h3>
          <div className="flex items-center gap-2 text-[10px] text-gray-500 uppercase font-black tracking-widest border border-gray-800 px-3 py-1 rounded-full">
            <History className="w-3 h-3" />
            Recent
          </div>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-24 bg-gray-900 border border-gray-800 rounded-[2rem] animate-pulse"></div>
            ))}
          </div>
        ) : transactions.length === 0 ? (
          <div className="py-16 text-center bg-gray-900/50 rounded-[2rem] border border-gray-800 border-dashed">
            <p className="text-gray-500 font-black uppercase tracking-widest text-xs italic">No activity yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {transactions.map((tx) => (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                key={tx.id} 
                className="bg-gray-900 border border-gray-800 rounded-[2rem] p-6 flex items-center justify-between group hover:border-gray-700 transition-all"
              >
                <div className="flex items-center gap-6">
                  <div className={cn(
                    "w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg",
                    tx.type === 'deposit' || tx.type === 'winning' ? "bg-green-600 text-white shadow-green-600/10" : "bg-red-600 text-white shadow-red-600/10"
                  )}>
                    {tx.type === 'deposit' || tx.type === 'winning' ? <ArrowDownLeft className="w-6 h-6" /> : <ArrowUpRight className="w-6 h-6" />}
                  </div>
                  <div>
                    <p className="font-black text-white text-lg italic uppercase tracking-tighter leading-none mb-1">
                      {tx.type.replace('_', ' ')}
                    </p>
                    <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">
                      {format(new Date(tx.createdAt), 'MMM dd | p')}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={cn(
                    "text-xl font-black italic",
                    tx.type === 'deposit' || tx.type === 'winning' ? "text-green-500" : "text-red-500"
                  )}>
                    {tx.type === 'deposit' || tx.type === 'winning' ? '+' : '-'}{formatCurrency(tx.amount)}
                  </p>
                  <div className="flex flex-col items-end">
                    <span className={cn(
                      "text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full border",
                      tx.status === 'success' ? "border-green-600/30 text-green-600 bg-green-600/5" :
                      tx.status === 'pending' ? "border-yellow-600/30 text-yellow-600 bg-yellow-600/5" :
                      "border-red-600/30 text-red-600 bg-red-600/5"
                    )}>
                      {tx.status}
                    </span>
                    {tx.paymentMethod && (
                      <span className="text-[7px] text-gray-600 font-bold uppercase mt-1">
                        {tx.paymentMethod}: {tx.paymentDetails?.slice(0, 10)}...
                      </span>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
