import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Tournament } from '../types';
import { Trophy, Users, Clock, Gamepad2, ChevronLeft, LayoutGrid } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';

export default function Tournaments() {
  const [searchParams] = useSearchParams();
  const type = searchParams.get('type') || 'br';
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'upcoming' | 'ongoing' | 'completed'>('upcoming');

  const modeLabels: Record<string, string> = {
    'cs': 'Clash Squad (4v4)',
    'lw': 'Lone Wolf (1v1)',
    'br': 'Battle Royale (SQUAD/SOLO)'
  };

  const modeMatch: Record<string, string> = {
    'cs': 'Clash Squad',
    'lw': 'Lone Wolf',
    'br': 'Battle Royale'
  };

  useEffect(() => {
    setLoading(true);
    const q = query(
      collection(db, 'tournaments'),
      where('gameMode', '==', modeMatch[type] || 'Battle Royale'),
      orderBy('matchTime', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Tournament[];
      setTournaments(data);
      setLoading(false);
    }, (error) => {
      console.error("Tournaments load error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [type]);

  const filteredTournaments = tournaments.filter(t => {
    if (activeTab === 'upcoming') return t.status === 'upcoming';
    if (activeTab === 'ongoing') return t.status === 'ongoing';
    if (activeTab === 'completed') return t.status === 'completed';
    return false;
  });

  return (
    <div className="space-y-6 pb-20">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link to="/" className="p-2 rounded-xl bg-gray-900 border border-gray-800 text-gray-400 hover:text-white transition-colors">
          <ChevronLeft className="w-6 h-6" />
        </Link>
        <div>
          <h1 className="text-2xl font-black text-white italic uppercase tracking-tighter">
            {modeLabels[type] || 'Tournaments'}
          </h1>
          <p className="text-blue-500 text-[10px] font-bold uppercase tracking-widest">Available Matches</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex bg-gray-900/50 p-1 rounded-2xl border border-gray-800">
        {(['upcoming', 'ongoing', 'completed'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              "flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all",
              activeTab === tab 
                ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20" 
                : "text-gray-500 hover:text-gray-300"
            )}
          >
            {tab === 'completed' ? 'Results' : tab}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="space-y-4">
        {loading ? (
          <div className="grid gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-32 bg-gray-900 rounded-3xl animate-pulse border border-gray-800"></div>
            ))}
          </div>
        ) : filteredTournaments.length === 0 ? (
          <div className="text-center py-20 bg-gray-900/30 rounded-[2.5rem] border border-gray-800 border-dashed">
            <LayoutGrid className="w-12 h-12 text-gray-800 mx-auto mb-4 opacity-50" />
            <p className="text-gray-500 font-black uppercase italic tracking-widest text-xs">No {activeTab} matches</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {filteredTournaments.map((tournament) => (
              <Link 
                key={tournament.id} 
                to={`/tournaments/${tournament.id}`}
                className="block group"
              >
                <div className="bg-gray-900 border border-gray-800 rounded-3xl p-5 transition-all hover:border-blue-500/30 hover:bg-gray-900/80">
                  <div className="flex gap-4">
                    <div className="w-24 h-24 rounded-2xl bg-gray-800 flex-shrink-0 overflow-hidden border border-gray-700">
                      {tournament.thumbnail ? (
                        <img src={tournament.thumbnail} className="w-full h-full object-cover" alt={tournament.title} />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Gamepad2 className="w-10 h-10 text-gray-700" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start">
                          <h4 className="font-black text-white truncate text-lg italic tracking-tight uppercase group-hover:text-blue-400 transition-colors">
                            {tournament.title}
                          </h4>
                          <span className={cn(
                            "text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-widest border",
                            tournament.status === 'completed' 
                              ? "bg-green-600/10 text-green-500 border-green-500/20"
                              : "bg-blue-600/10 text-blue-500 border-blue-500/20"
                          )}>
                            {tournament.status === 'completed' ? 'FINISHED' : tournament.version || 'MOBILE'}
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <div className="flex items-center gap-1.5 bg-yellow-500/10 border border-yellow-500/20 px-2 py-1 rounded-lg shadow-[0_0_15px_rgba(234,179,8,0.05)]">
                            <Trophy className="w-3 h-3 text-yellow-500" />
                            <span className="text-[10px] font-black text-yellow-500 uppercase tracking-tighter">
                              {formatCurrency(tournament.prizePool)}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 bg-gray-950 border border-gray-800 px-2 py-1 rounded-lg">
                            <Users className="w-3 h-3 text-blue-500" />
                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-tighter">
                              {tournament.playersCount}/{tournament.maxPlayers}
                            </span>
                          </div>
                          {tournament.status === 'completed' && tournament.winnerKills !== undefined && (
                            <div className="flex items-center gap-1.5 bg-red-500/10 border border-red-500/20 px-2 py-1 rounded-lg">
                              <span className="text-[10px] font-black text-red-500 uppercase tracking-tighter">
                                {tournament.winnerKills} KILLS
                              </span>
                            </div>
                          )}
                        </div>
                      </div>

                      {tournament.status === 'completed' ? (
                        <div className="flex items-center justify-between pt-4 border-t border-gray-800 mt-4 h-12">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-yellow-500/20 flex items-center justify-center border border-yellow-500/30 shadow-[0_0_15px_rgba(234,179,8,0.2)]">
                              <Trophy className="w-4 h-4 text-yellow-500" />
                            </div>
                            <div>
                              <p className="text-[7px] font-black text-gray-600 uppercase tracking-widest">WINNER</p>
                              <p className="text-xs font-black text-yellow-500 uppercase italic tracking-tight drop-shadow-[0_0_8px_rgba(234,179,8,0.4)]">
                                {tournament.winnerName || 'N/A'}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-[7px] font-black text-gray-600 uppercase tracking-widest">Distributed</p>
                            <p className="text-xs font-black text-green-500 italic tracking-tighter">
                              {formatCurrency(tournament.winnerPrize || tournament.prizePool)}
                            </p>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between pt-4 border-t border-gray-800 mt-4 h-12">
                          <div className="flex items-center gap-2 text-[10px] font-black text-gray-500 uppercase tracking-widest">
                            <Clock className="w-3 h-3 text-green-500" />
                            {format(new Date(tournament.matchTime), 'MMM dd, p')}
                          </div>
                          <div className="text-xs font-black text-white bg-blue-600 px-4 py-1.5 rounded-xl shadow-lg shadow-blue-600/20 italic tracking-tighter uppercase transition-transform group-hover:scale-105 active:scale-95">
                            {tournament.entryFee === 0 ? 'FREE' : `JOIN • ${formatCurrency(tournament.entryFee)}`}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
