import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { collection, query, where, onSnapshot, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Tournament } from '../types';
import { Swords, Trophy, Clock, Lock, Key, AlertCircle, CheckCircle2 } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { format, differenceInMinutes, isAfter, subMinutes } from 'date-fns';
import { motion } from 'motion/react';

interface JoinedTournament extends Tournament {
  registrationStatus: string;
}

export default function MyMatches() {
  const { user } = useAuth();
  const [matches, setMatches] = useState<JoinedTournament[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 30000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!user) return;
    
    // collectionGroup needs index deployment in Firestore, but for subcollections we can try to query all tournaments
    // For this demo, let's assume we can fetch them by looking at registrations.
    // However, without Admin/Backend indexing, querying subcollections across parents is tricky.
    // Instead, I'll fetch all tournaments and filter by local knowledge or a collection of 'user_registrations'.
    // Given my blueprint had registrations as subcollections, I'll adjust the strategy.
    
    // Better strategy for this demo: query a flattened 'registrations' collection if it exists,
    // or just fetch all tournaments and check if user is in their registrations subcollection.
    // Since I can't easily query across all subcollections without an index, 
    // I'll fetch all and filter manually for the prototype.
    
    const unsubscribe = onSnapshot(collection(db, 'tournaments'), async (snapshot) => {
      const activeTournaments = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Tournament));
      
      const joined: JoinedTournament[] = [];
      for (const t of activeTournaments) {
        const regRef = query(collection(db, 'tournaments', t.id, 'registrations'), where('userId', '==', user.uid));
        // This is not efficient but works for small demo
        const regSnap = await getDocs(regRef);
        if (!regSnap.empty) {
          joined.push({ ...t, registrationStatus: regSnap.docs[0].data().status });
        }
      }
      setMatches(joined);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white tracking-tight">My Matches</h1>
        <div className="bg-blue-600/20 text-blue-500 text-[10px] font-black px-2 py-1 rounded border border-blue-500/20 uppercase">
          {matches.length} Active
        </div>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2].map(i => (
            <div key={i} className="h-40 bg-gray-900 rounded-3xl animate-pulse"></div>
          ))}
        </div>
      ) : matches.length === 0 ? (
        <div className="py-20 text-center bg-gray-900/50 rounded-[2.5rem] border border-gray-800 border-dashed px-8">
          <div className="w-20 h-20 rounded-full bg-gray-800 flex items-center justify-center mx-auto mb-6">
            <Swords className="w-10 h-10 text-gray-700" />
          </div>
          <h3 className="text-white font-bold text-lg mb-2">No Matches Yet</h3>
          <p className="text-gray-500 text-sm mb-8">Join a tournament from the home screen to start competing and winning prizes!</p>
          <button className="bg-blue-600 text-white font-bold py-3 px-8 rounded-2xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/20">
            Explore Tournaments
          </button>
        </div>
      ) : (
        <div className="grid gap-6">
          {matches.map((match) => (
            <motion.div 
              key={match.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-gray-900 border border-gray-800 rounded-[2.5rem] p-6 space-y-6 relative overflow-hidden"
            >
              {(() => {
                const matchTime = new Date(match.matchTime);
                const isRevealTime = isAfter(currentTime, subMinutes(matchTime, 15));
                const hasCredentials = match.roomId && match.roomPassword;

                return (
                  <>
                    <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/5 blur-3xl rounded-full translate-x-16 -translate-y-16"></div>
                    
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="bg-blue-600/20 text-blue-500 text-[10px] font-bold px-2 py-0.5 rounded-full inline-block mb-2 uppercase tracking-widest">
                          {match.game}
                        </div>
                        <h3 className="text-xl font-bold text-white">{match.title}</h3>
                      </div>
                        <div className="flex flex-col items-end gap-2">
                          <div className={cn(
                            "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest",
                            match.status === 'upcoming' ? "bg-blue-600/20 text-blue-500" :
                            match.status === 'ongoing' ? "bg-orange-600/20 text-orange-500" :
                            match.status === 'completed' ? "bg-green-600/20 text-green-500" :
                            "bg-red-600/20 text-red-500"
                          )}>
                            {match.status}
                          </div>
                          <div className="flex flex-col items-end">
                            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1 italic">Prize Pool</span>
                            <span className="text-lg font-black text-yellow-500">{formatCurrency(match.prizePool)}</span>
                          </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-gray-950 p-4 rounded-2xl border border-gray-800 flex flex-col items-center justify-center space-y-1">
                        <Clock className="w-4 h-4 text-blue-500" />
                        <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Starts At</span>
                        <span className="text-xs font-bold text-white whitespace-nowrap">{format(matchTime, 'p, MMM dd')}</span>
                      </div>
                      <div className="bg-gray-950 p-4 rounded-2xl border border-gray-800 flex flex-col items-center justify-center space-y-1">
                        <Trophy className="w-4 h-4 text-yellow-500" />
                        <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Team Stats</span>
                        <span className="text-xs font-bold text-white">READY</span>
                      </div>
                    </div>

                    {/* Secure Info Section */}
                    {match.status === 'upcoming' || match.status === 'ongoing' ? (
                      isRevealTime && hasCredentials ? (
                        <div className="bg-green-600/10 border border-green-500/20 rounded-[2rem] p-5 space-y-4">
                          <div className="flex items-center justify-between">
                            <p className="text-[10px] font-black text-green-500 uppercase tracking-[0.2em] italic">Room Credentials Live</p>
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                              <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">Room ID</p>
                              <p className="text-white font-black tracking-widest select-all bg-gray-950 px-3 py-2 rounded-xl border border-gray-800/50">{match.roomId}</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">Password</p>
                              <p className="text-white font-black tracking-widest select-all bg-gray-950 px-3 py-2 rounded-xl border border-gray-800/50">{match.roomPassword}</p>
                            </div>
                          </div>
                          <button 
                            onClick={() => {
                              navigator.clipboard.writeText(`ID: ${match.roomId} | PASS: ${match.roomPassword}`);
                              alert('Credentials copied to clipboard!');
                            }}
                            className="w-full py-2.5 bg-green-600 text-white font-black text-[10px] uppercase tracking-widest rounded-xl hover:bg-green-700 transition-all flex items-center justify-center gap-2"
                          >
                            <Key className="w-3 h-3" />
                            Copy All
                          </button>
                        </div>
                      ) : (
                        <div className="bg-blue-600/10 border border-blue-500/20 rounded-2x2 p-4 flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center flex-shrink-0">
                            <Lock className="w-5 h-5 text-white" />
                          </div>
                          <div className="flex-1">
                            <p className="text-xs font-bold text-blue-400 uppercase tracking-widest leading-none mb-1">Room Credentials</p>
                            <p className="text-[10px] text-gray-500">
                              {isRevealTime ? "Admin hasn't uploaded ID/Pass yet." : "Reveals 15 mins before match starts."}
                            </p>
                          </div>
                          <button className="bg-gray-950 p-2 rounded-lg border border-gray-800 text-gray-400">
                            <Key className="w-4 h-4" />
                          </button>
                        </div>
                      )
                    ) : match.status === 'completed' ? (
                        <div className="bg-gray-950 border border-gray-800 rounded-3xl p-4 flex items-center gap-3">
                          <CheckCircle2 className="w-5 h-5 text-green-500" />
                          <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Match Completed - Results Declared</p>
                        </div>
                    ) : (
                        <div className="bg-red-600/10 border border-red-500/20 rounded-3xl p-4 flex items-center gap-3">
                          <AlertCircle className="w-5 h-5 text-red-500" />
                          <p className="text-xs font-bold text-red-500 uppercase tracking-widest">Match Cancelled - Refund Processed</p>
                        </div>
                    )}

                    <div className="flex items-center gap-2 text-[10px] text-gray-500 font-medium">
                      <AlertCircle className="w-3 h-3 text-yellow-500" />
                      Please ensure your Game ID matches your profile to avoid disqualification.
                    </div>
                  </>
                );
              })()}
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
