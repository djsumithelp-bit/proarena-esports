import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { doc, onSnapshot, setDoc, getDoc, updateDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { UserProfile } from '../types';

const generateProId = () => Math.floor(100000 + Math.random() * 900000).toString();

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      
      if (unsubscribeProfile) {
        unsubscribeProfile();
        unsubscribeProfile = null;
      }

      if (firebaseUser) {
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        
        // Listen to profile changes
        unsubscribeProfile = onSnapshot(userDocRef, async (snap) => {
          if (snap.exists()) {
            const data = snap.data() as UserProfile;
            
            // Assign Pro ID if missing
            if (!data.proId) {
              const newProId = generateProId();
              await updateDoc(userDocRef, { proId: newProId });
              data.proId = newProId;
            }

            // Force super admin role for the system admin email
            if (firebaseUser.email === 'sumitdhakad4424@gmail.com') {
              data.role = 'super_admin';
              data.isBlocked = false;
            }
            
            setProfile(data);
            setLoading(false);
          } else {
            // Document doesn't exist, create it
            const isSuperAdmin = firebaseUser.email === 'sumitdhakad4424@gmail.com';
            const newProfile: UserProfile = {
              uid: firebaseUser.uid,
              proId: generateProId(),
              email: firebaseUser.email || '',
              displayName: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
              balance: { deposit: 0, winning: 0 },
              role: isSuperAdmin ? 'super_admin' : 'user',
              createdAt: new Date().toISOString(),
            };
            
            setDoc(userDocRef, newProfile)
              .catch(err => console.error("Profile creation error:", err));
          }
        }, (error) => {
          console.error("Profile snapshot error:", error);
          setLoading(false);
        });
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
    };
  }, []);

  const signOut = () => auth.signOut();

  return (
    <AuthContext.Provider value={{ user, profile, loading, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
